/**
 * 
 */
package utility;

import java.math.BigInteger;

import utility.security.Gfunction;

/**
 * @author chenqian
 *
 */
public class test_of_g_function {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long start = System.currentTimeMillis();
		int x = 1000, y = 10202, scale = 1000000, times = 1000;
		//server side for new g function
		BigInteger tmpx = new BigInteger("1"), tmpy = SecurityUtility.computeFunctionG(1.0 * (scale - x) / scale);
		start = System.currentTimeMillis();
		for(int i = 0; i < times; i++){
			tmpx = SecurityUtility.computeFunctionG(1.0 * (y - x) / scale);
		}
		System.out.println("New g function for server costs: " + (System.currentTimeMillis() - start));
		//client side for new g gunction
		start = System.currentTimeMillis();
		for(int i = 0; i < times; i++){
			if(SecurityUtility.combineFunctionG(tmpx, 1.0 * (scale - y) / scale).equals(tmpy)){
				//System.out.println("Pass verification!");
			}else{
				System.out.println("Fail verification!");
			}
		}
		System.out.println("New g function for client costs: " + (System.currentTimeMillis() - start));
		
		Gfunction gf = new Gfunction(x, 10, 0, scale);
		start = System.currentTimeMillis();
		//server side for old g fucntion
		for(int i = 0; i < times; i++){
			//gf = new Gfunction(x, 10, 0, scale);
			gf.GenerateVeryfyPart(y);
		}
		System.out.println("Old g function for server costs: " + (System.currentTimeMillis() - start));
		//client side for old g fucntion
		start = System.currentTimeMillis();
		for(int i = 0; i < times; i++){
			if(gf.ClientVerifyU(scale - y)){
				//System.out.println("Pass verification!");
			}else{
				System.out.println("Fail verification!");
			}
		}
		System.out.println("Old g function for client costs: " + (System.currentTimeMillis() - start));
	}

}
