package spatialindex.rtree;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import spatialindex.core.IShape;
import spatialindex.core.IVisitor;
import spatialindex.core.Point;
import spatialindex.core.Region;
import spatialindex.core.VOErrorException;
import utility.StatisticForAuth;
import utility.Compare.DataOfPoint;
import utility.Compare.DistanceCompare;
import utility.geo.DataOfLine;
import utility.geo.Line;
import utility.security.DataIO;
import utility.security.Gfunction;
import utility.security.Hasher;
import utility.security.SecurityUtility;

/**
 * @author chenqian
 * */

public class VO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int queryHits;
	
	/**
	 * use for counting in analyzing VO String
	 */
	private String rsaEntaValue;
	
	private HashMap<Integer, VOCell> nodeVO = new HashMap<Integer, VOCell>();
	private HashMap<Integer, VOCell> dataVO = new HashMap<Integer, VOCell>();
	private ArrayList<dcCell> dcVO = new ArrayList<dcCell>();
	private ArrayList<lineCell> lineVO = new ArrayList<lineCell>();
	private ArrayList<gfCell> gfVO = new ArrayList<gfCell>();
	private RTree rtree;
	private SecurityTree srtree;
	private StatisticForAuth statForAuth;
	private String sigWithRSA;
	private int type_VO; // 0 means rtree based, 1 means voronoi diagram based
	public VO(){
		
	}
	
	/**
	 * For Voronoi Diagram
	 * */
	public VO(int k, final IShape query, HashMap<Integer, Integer> dataState, boolean greedy, RTree _rtree){
		statForAuth = new StatisticForAuth();
		rtree = _rtree;
		type_VO = 1;
		ThreadMXBean bean = ManagementFactory.getThreadMXBean();
		long start = bean.getCurrentThreadCpuTime(), end;
		
		Integer[] dataList = new Integer[dataState.size()], fDataList = new Integer[dataState.size()];
		int dataLen = 0, fDataLen = 1;
		Iterator<Integer> iter = dataState.keySet().iterator();
		HashSet<Integer> neighborIds = new HashSet<Integer>();
		while(iter.hasNext()){
			int key = iter.next();
//			System.out.print(key + " ");
			if(dataState.get(key) == 0){
				dataList[dataLen ++] = key;
				DataOfPoint dop = rtree.loadDataOfPointFromBtree(key);
				for(int i = 0; i < dop.delaunayIds.length; i++){
					if(neighborIds.contains(dop.delaunayIds[i].intValue()) == false && (dataState.containsKey(dop.delaunayIds[i].intValue()) == false || dataState.get(dop.delaunayIds[i].intValue()) == 1)){
						fDataList[fDataLen ++] = dop.delaunayIds[i].intValue();
						neighborIds.add(dop.delaunayIds[i].intValue());
					}
				}
			}
		}
		Arrays.sort(fDataList, 1, fDataLen, new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				// TODO Auto-generated method stub
				DataOfPoint dp1 = rtree.loadDataOfPointFromBtree(o1.longValue());
				DataOfPoint dp2 = rtree.loadDataOfPointFromBtree(o2.longValue());
				double dist1 = query.getMinimumDistance(new Point(new double[]{dp1.p.x, dp1.p.y}));
				double dist2 = query.getMinimumDistance(new Point(new double[]{dp2.p.x, dp2.p.y}));
				if(dist1 < dist2) return -1;
				else if(dist1 > dist2)return 1;
				return 0;
			}
		});
		Arrays.sort(dataList, 0, dataLen, new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				// TODO Auto-generated method stub
				DataOfPoint dp1 = rtree.loadDataOfPointFromBtree(o1.longValue());
				DataOfPoint dp2 = rtree.loadDataOfPointFromBtree(o2.longValue());
				double dist1 = query.getMinimumDistance(new Point(new double[]{dp1.p.x, dp1.p.y}));
				double dist2 = query.getMinimumDistance(new Point(new double[]{dp2.p.x, dp2.p.y}));
				if(dist1 > dist2) return -1;
				else if(dist1 < dist2)return 1;
				return 0;
			}
		});
		fDataList[0] = dataList[0];
		if(greedy){
			for(int i = 0; i < dataLen; i ++){
				Integer pi = dataList[i];
				dataVO.put(pi, new VOCell(false, rtree.loadDataOfPointFromBtree(pi), -1));
				if(i == 0)continue;
				boolean found = false;
				for(int j = 0; j < i; j++){//Dist(j, k) >= Dist(i, k)
					Integer pj = dataList[j];
					DataOfLine dataofline = null;
					if((dataofline = rtree.loadDataOfLineFromBtree(pi, pj)) != null){						
						lineCell linecell = new lineCell(dataofline);
						linecell.generateVeryfyPart((Point)query);
						lineVO.add(linecell);
						found = true;
						break;
					}
				}
				if(found == false){
					dcCell dccell = new dcCell(dataVO.get(pi).dataOfPoint.p, dataVO.get(dataList[0]).dataOfPoint.p);
					dccell.generateVeryfyPart((Point)query);
					dcVO.add(dccell);
				}
			}
			for(int i = 1; i < fDataLen; i ++){
				Integer pi = fDataList[i];
				dataVO.put(pi, new VOCell(true, rtree.loadDataOfPointFromBtree(pi), -1));
				boolean found = false;
				for(int j = 0; j < i; j++){//Dist(j, k) >= Dist(i, k)
					Integer pj = fDataList[j];
					DataOfLine dataofline = null;
					if((dataofline = rtree.loadDataOfLineFromBtree(pi, pj)) != null){						
						lineCell linecell = new lineCell(dataofline);
						linecell.generateVeryfyPart((Point)query);
						lineVO.add(linecell);
						found = true;
						break;
					}
				}
				if(found == false){
					dcCell dccell = new dcCell(dataVO.get(fDataList[0]).dataOfPoint.p, dataVO.get(pi).dataOfPoint.p);
					dccell.generateVeryfyPart((Point)query);
					dcVO.add(dccell);
				}
			}
		}else{
			for(int i = 0; i < dataLen; i++){
				Integer pi = dataList[i];
				dataVO.put(pi, new VOCell(false, rtree.loadDataOfPointFromBtree(pi), -1));
//				System.out.println("res : " + pi + " distance : " + 
//						utility.security.Point.Distance2((long)((Point)query).getCoord(0), (long)((Point)query).getCoord(1), 
//						dataVO.get(pi).dataOfPoint.p.x, dataVO.get(pi).dataOfPoint.p.y));
				if(i == 0)continue;
				DataOfLine dataofline = null;
				if((dataofline = rtree.loadDataOfLineFromBtree(pi, dataList[0])) != null){
					lineCell linecell = new lineCell(dataofline);
					linecell.generateVeryfyPart((Point)query);
					lineVO.add(linecell);
				}else{
					dcCell dccell = new dcCell(dataVO.get(pi).dataOfPoint.p, dataVO.get(dataList[0]).dataOfPoint.p);
					dccell.generateVeryfyPart((Point)query);
					if(dccell.verify((Point)query) == false){
						System.err.println("Err res: " + pi);
					}
					dcVO.add(dccell);
				}
			}
			for(int i = 1; i < fDataLen; i++){
				Integer pi = fDataList[i];
				dataVO.put(pi, new VOCell(true, rtree.loadDataOfPointFromBtree(pi), -1));
				DataOfLine dataofline = null;
//				System.out.println("far : " + pi + " distance : " + 
//						utility.security.Point.Distance2((long)((Point)query).getCoord(0), (long)((Point)query).getCoord(1), 
//						dataVO.get(pi).dataOfPoint.p.x, dataVO.get(pi).dataOfPoint.p.y));
				if((dataofline = rtree.loadDataOfLineFromBtree(pi, fDataList[0])) != null){
					lineCell linecell = new lineCell(dataofline);
					linecell.generateVeryfyPart((Point)query);
					lineVO.add(linecell);
				}else{
					dcCell dccell = new dcCell(dataVO.get(fDataList[0]).dataOfPoint.p, dataVO.get(pi).dataOfPoint.p);
					dccell.generateVeryfyPart((Point)query);
					if(dccell.verify((Point)query) == false){
						dccell.dc.pL.print();
						dccell.dc.pH.print();
						System.err.println("Err far: " + pi);
					}
					dcVO.add(dccell);
				}
			}
		}
		ArrayList<String> sigs = new ArrayList<String>();
		for(int i = 0; i < dataLen; i++){
			sigs.add(dataVO.get(dataList[i]).dataOfPoint.getSignature());
		}
		for(int i = 1; i < fDataLen; i++){
			sigs.add(dataVO.get(fDataList[i]).dataOfPoint.getSignature());
		}
		sigWithRSA = SecurityUtility.rsa.getCondensedRSA(sigs.toArray(new String[0]));
		end = bean.getCurrentThreadCpuTime();
		statForAuth.con_time_SP += (end - start) / 1000000.0;
		statForAuth.size_VO += getVOSize();
	}
	
	public VO(int k, final IShape query, HashMap<Integer, Integer> nodeState, HashMap<Integer, Integer> dataState, 
			boolean greedy, RTree _rtree, SecurityTree _srtree){
		statForAuth = new StatisticForAuth();
		rtree = _rtree;
		srtree = _srtree;
		type_VO = 0;
		ThreadMXBean bean = ManagementFactory.getThreadMXBean();
		long start = bean.getCurrentThreadCpuTime(), end;
		Integer[] dataList = new Integer[dataState.size()], fDataList = new Integer[dataState.size()];
		int dataLen = 0, fDataLen = 1;
		Iterator<Integer> iter = dataState.keySet().iterator();
		while(iter.hasNext()){
			int key = iter.next();
//			System.out.print(key + " ");
			if(dataState.get(key) == 0){
				dataList[dataLen ++] = key;
			}else{
				fDataList[fDataLen ++] = key;
			}
		}
		iter = nodeState.keySet().iterator();
		while(iter.hasNext()){
			int key = iter.next();
			if(nodeState.get(key) == 0){
				Node node = rtree.readNode(key);
				SecurityNode snode = srtree.getSecurityNode(key);
				int[] childIdentidiers = new int[node.getChildrenCount()];
				for(int i = 0; i < node.getChildrenCount(); i++){
					childIdentidiers[i] = node.getChildIdentifier(i);
				}
				nodeVO.put(key, new VOCell(false, snode.getMbrDigest(), childIdentidiers, node.m_level));
			}else{
				Node node = rtree.readNode(key);
				SecurityNode snode = srtree.getSecurityNode(key);
				//System.out.println(key);
				nodeVO.put(key, new VOCell(true, snode.getChildDigest(), snode.getMbrDigest(), node.m_level));
				Region region = node.m_nodeMBR;
				DataOfPoint[] dops = snode.getDOPs(rtree);
				gfCell gfcell = new gfCell();
				if(query.getMBR().m_pLow[0] < region.m_pLow[0])gfcell.setGf(dops[0].gf_x, true);
				if(query.getMBR().m_pLow[0] > region.m_pHigh[0])gfcell.setGf(dops[1].gf_x, false);
				if(query.getMBR().m_pLow[1] < region.m_pLow[1])gfcell.setGf2(dops[0].gf_y, true);
				if(query.getMBR().m_pLow[1] > region.m_pHigh[1])gfcell.setGf2(dops[1].gf_y, false);
				gfcell.generateVeryfyPart((Point)query);
				gfVO.add(gfcell);
			}
		}
		Arrays.sort(fDataList, 1, fDataLen, new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				// TODO Auto-generated method stub
				DataOfPoint dp1 = rtree.loadDataOfPointFromBtree(o1.longValue());
				DataOfPoint dp2 = rtree.loadDataOfPointFromBtree(o2.longValue());
				double dist1 = query.getMinimumDistance(new Point(new double[]{dp1.p.x, dp1.p.y}));
				double dist2 = query.getMinimumDistance(new Point(new double[]{dp2.p.x, dp2.p.y}));
				if(dist1 < dist2) return -1;
				else if(dist1 > dist2)return 1;
				return 0;
			}
		});
		Arrays.sort(dataList, 0, dataLen, new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				// TODO Auto-generated method stub
				DataOfPoint dp1 = rtree.loadDataOfPointFromBtree(o1.longValue());
				DataOfPoint dp2 = rtree.loadDataOfPointFromBtree(o2.longValue());
				double dist1 = query.getMinimumDistance(new Point(new double[]{dp1.p.x, dp1.p.y}));
				double dist2 = query.getMinimumDistance(new Point(new double[]{dp2.p.x, dp2.p.y}));
				if(dist1 > dist2) return -1;
				else if(dist1 < dist2)return 1;
				return 0;
			}
		});
		fDataList[0] = dataList[0];
		if(greedy){
			for(int i = 0; i < dataLen; i ++){
				Integer pi = dataList[i];
				dataVO.put(pi, new VOCell(false, rtree.loadDataOfPointFromBtree(pi), -1));
				if(i == 0)continue;
				boolean found = false;
				for(int j = 0; j < i; j++){//Dist(j, k) >= Dist(i, k)
					Integer pj = dataList[j];
					DataOfLine dataofline = null;
					if((dataofline = rtree.loadDataOfLineFromBtree(pi, pj)) != null){						
						lineCell linecell = new lineCell(dataofline);
						linecell.generateVeryfyPart((Point)query);
						lineVO.add(linecell);
						found = true;
						break;
					}
				}
				if(found == false){
					dcCell dccell = new dcCell(dataVO.get(pi).dataOfPoint.p, dataVO.get(dataList[0]).dataOfPoint.p);
					dccell.generateVeryfyPart((Point)query);
					dcVO.add(dccell);
				}
			}
			for(int i = 1; i < fDataLen; i ++){
				Integer pi = fDataList[i];
				dataVO.put(pi, new VOCell(true, rtree.loadDataOfPointFromBtree(pi), -1));
				boolean found = false;
				for(int j = 0; j < i; j++){//Dist(j, k) >= Dist(i, k)
					Integer pj = fDataList[j];
					DataOfLine dataofline = null;
					if((dataofline = rtree.loadDataOfLineFromBtree(pi, pj)) != null){						
						lineCell linecell = new lineCell(dataofline);
						linecell.generateVeryfyPart((Point)query);
						lineVO.add(linecell);
						found = true;
						break;
					}
				}
				if(found == false){
					dcCell dccell = new dcCell(dataVO.get(fDataList[0]).dataOfPoint.p, dataVO.get(pi).dataOfPoint.p);
					dccell.generateVeryfyPart((Point)query);
					dcVO.add(dccell);
				}
			}
		}else{
			for(int i = 0; i < dataLen; i++){
				Integer pi = dataList[i];
				dataVO.put(pi, new VOCell(false, rtree.loadDataOfPointFromBtree(pi), -1));
//				System.out.println("res : " + pi + " distance : " + 
//						utility.security.Point.Distance2((long)((Point)query).getCoord(0), (long)((Point)query).getCoord(1), 
//						dataVO.get(pi).dataOfPoint.p.x, dataVO.get(pi).dataOfPoint.p.y));
				if(i == 0)continue;
				DataOfLine dataofline = null;
				if((dataofline = rtree.loadDataOfLineFromBtree(pi, dataList[0])) != null){
					lineCell linecell = new lineCell(dataofline);
					linecell.generateVeryfyPart((Point)query);
					lineVO.add(linecell);
				}else{
					dcCell dccell = new dcCell(dataVO.get(pi).dataOfPoint.p, dataVO.get(dataList[0]).dataOfPoint.p);
					dccell.generateVeryfyPart((Point)query);
					dcVO.add(dccell);
				}
			}
			for(int i = 1; i < fDataLen; i++){
				Integer pi = fDataList[i];
				dataVO.put(pi, new VOCell(true, rtree.loadDataOfPointFromBtree(pi), -1));
//				System.out.println("far : " + pi + " distance : " + 
//						utility.security.Point.Distance2((long)((Point)query).getCoord(0), (long)((Point)query).getCoord(1), 
//						dataVO.get(pi).dataOfPoint.p.x, dataVO.get(pi).dataOfPoint.p.y));
				DataOfLine dataofline = null;
				if((dataofline = rtree.loadDataOfLineFromBtree(pi, fDataList[0])) != null){
					lineCell linecell = new lineCell(dataofline);
					linecell.generateVeryfyPart((Point)query);
					lineVO.add(linecell);
				}else{
					dcCell dccell = new dcCell(dataVO.get(fDataList[0]).dataOfPoint.p, dataVO.get(pi).dataOfPoint.p);
					dccell.generateVeryfyPart((Point)query);
					dcVO.add(dccell);
				}
			}
		}
		end = bean.getCurrentThreadCpuTime();
		statForAuth.con_time_SP += (end - start) / 1000000.0;
		statForAuth.size_VO += getVOSize();
	}
	
	public long getVOSize(){
		long ans = 0;
		if(type_VO == 0){
			Iterator<Integer> iter = nodeVO.keySet().iterator();
			while(iter.hasNext()){
				ans += nodeVO.get(iter.next()).getVOSize();
			}
			iter = dataVO.keySet().iterator();
			while(iter.hasNext()){
				ans += dataVO.get(iter.next()).getVOSize();
			}
			for(int i = 0; i < dcVO.size(); i++){
				ans += dcVO.get(i).getVOSize();
			}
			for(int i = 0; i < lineVO.size(); i++){
				ans += lineVO.get(i).getVOSize();
			}
			for(int i = 0; i < gfVO.size(); i++){
				ans += gfVO.get(i).getVOSize();
			}
		}else{
			Iterator<Integer> iter = dataVO.keySet().iterator();
			while(iter.hasNext()){
				ans += dataVO.get(iter.next()).getVOSize();
			}
			for(int i = 0; i < dcVO.size(); i++){
				ans += dcVO.get(i).getVOSize();
			}
			for(int i = 0; i < lineVO.size(); i++){
				ans += lineVO.get(i).getVOSize();
			}
		}
		return ans;
	}
	
	public StatisticForAuth getStatistics(){
		return statForAuth;
	}
	
	public boolean is_veryfy(String computed) throws UnsupportedEncodingException{
		//System.out.println(new BigInteger(computed.getBytes("ISO-8859-1")).mod(SecurityUtility.rsa.n));
		//System.out.println(SecurityUtility.rsa.decrypt(new BigInteger(rsaEntaValue)));
		return new BigInteger(computed.getBytes( "ISO-8859-1")).mod(SecurityUtility.rsa.n).equals(SecurityUtility.rsa.decrypt(new BigInteger(rsaEntaValue)));
	}
	
	public String computeRootEnta(Region queryRegion) throws IndexOutOfBoundsException, Exception {
		return null;
	}

	public String getrsaEntaValue(){
		return null;
	}
	
	public void buildenta(VOCell cell, VOCell[] childCells, boolean parentNodeInside, Region queryRegion) throws IndexOutOfBoundsException, VOErrorException, Exception{
		
	}
	
	public String reConstruct(int root){
		if(nodeVO.containsKey(root) == false){
			System.err.println("Not found id :" + root);
			return "-1";
		}
		VOCell vocell = nodeVO.get(root);
		ArrayList<String> tmp = new ArrayList<String>();
		if(vocell.level > 0){
			tmp.add(vocell.mbrDigest);
			if(vocell.isFinish){
				tmp.add(vocell.childDigest);
			}else{
				ArrayList<String> tmp2 = new ArrayList<String>();
				for(int i = 0; i < vocell.childIdentifiers.length; i++){
					tmp2.add(reConstruct(vocell.childIdentifiers[i]));
				}
				try {
					tmp.add(SecurityUtility.computeHashValue(tmp2.toArray(new String[0])));
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}else{
			if(vocell.isFinish){
				tmp.add(vocell.childDigest);
			}else{
				ArrayList<String> tmp2 = new ArrayList<String>();
				for(int i = 0; i < vocell.childIdentifiers.length; i++){
					if(dataVO.containsKey(vocell.childIdentifiers[i]) == false){
						System.err.println("Not found data id: " + vocell.childIdentifiers[i]);
						return "-1";
					}
					VOCell datacell = dataVO.get(vocell.childIdentifiers[i]);
//					System.err.println(srtree.getSecurityNode(root).getChildGValueById(i));
//					System.err.println(datacell.dataOfPoint.p.getDigest());
//					if(DataIO.compareString(datacell.dataOfPoint.p.getDigest(), srtree.getSecurityNode(root).getChildGValueById(i)) == false){
//						System.err.println("Err at data entry : " + i + ", " + vocell.childIdentifiers[i] + ", " + rtree.readNode(root).getChildIdentifier(i));
//						if(DataIO.compareString(rtree.loadDataOfPointFromBtree(vocell.childIdentifiers[i]).p.getDigest(), datacell.dataOfPoint.p.getDigest()) == false){
//							System.err.println("!!!!");
//						}
//						if(DataIO.compareString(rtree.loadDataOfPointFromBtree(vocell.childIdentifiers[i]).p.getDigest(), srtree.getSecurityNode(root).getChildGValueById(i)) == false){
//							System.err.println("!!!!");
//						}
//					}
					tmp2.add(datacell.dataOfPoint.p.getDigest());
					tmp2.add(new Integer(vocell.childIdentifiers[i]).toString());	
				}
				try {
					tmp.add(SecurityUtility.computeHashValue(tmp2.toArray(new String[0])));
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			tmp.add(vocell.mbrDigest);	
		}
		try {
			//System.out.println("now id: " + root);
			String digest = SecurityUtility.computeHashValue(tmp.toArray(new String[0]));
//			if(DataIO.compareString(digest, srtree.getSecurityNode(root).getEntaValue()) == false){
//				System.err.println("Err at id:" + root);
//			}else{
//				System.out.println("Pass at id:" + root);
//			}
			return digest;
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	
	public boolean verify(Point query){
		statForAuth.num_PPB += dcVO.size();
		statForAuth.num_PLB += lineVO.size();
		statForAuth.num_Gf += gfVO.size();
		
		ThreadMXBean bean = ManagementFactory.getThreadMXBean();
		long start = bean.getCurrentThreadCpuTime(), end;
		if(type_VO == 0){			
			for(int i = 0; i < dcVO.size(); i++){
				if(!dcVO.get(i).verify(query))return false;
			}
			System.out.println("Pass dc!");
			for(int i = 0; i < lineVO.size(); i++){
				if(!lineVO.get(i).verify(query))return false;
			}
			System.out.println("Pass line!");
			for(int i = 0; i < gfVO.size(); i++){
				if(!gfVO.get(i).verify(query))return false;
			}
			System.out.println("Pass gf!");
			String rootDigest = reConstruct(rtree.m_rootID);
			//System.out.println(rootDigest);System.out.println(srtree.getRootEntaValue());
			try {
				if(DataIO.compareStringInRSA(SecurityUtility.deSignWithRSA(srtree.getrsarootentaValue()), rootDigest) == false)return false;
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			ArrayList<String> digests = new ArrayList<String>();
			for(int i = 0; i < dcVO.size(); i++){
				//System.out.println(i);
				if(!dcVO.get(i).verify(query))return false;
			}
			System.out.println("Pass dc!");
			for(int i = 0; i < lineVO.size(); i++){
				if(!lineVO.get(i).verify(query))return false;
			}
			System.out.println("Pass line!");
			
			Iterator<Integer> iter = dataVO.keySet().iterator();
			while(iter.hasNext()){
				digests.add(dataVO.get(iter.next()).dataOfPoint.getDigest());
			}
			String combineDig = SecurityUtility.rsa.getCondensedRSA(digests.toArray(new String[0]));
			try {
				if(DataIO.compareStringInRSA(combineDig, SecurityUtility.deSignWithRSA(sigWithRSA)) == false)return false;
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		end = bean.getCurrentThreadCpuTime();
		statForAuth.vrf_time_CL += (end - start) / 1000000.0;
		return true;
	}

	private VOCell verify(Region queryRegion, boolean parentNodeInside) throws IndexOutOfBoundsException, Exception {
		return null;
	}

	public byte[] writeToBytes() throws IOException{
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);
		dos.writeInt(nodeVO.size());
		dos.writeInt(dataVO.size());
		dos.flush();
		dos.close();
		return baos.toByteArray();
	}
	
	public void readFromBytes(byte[] data) throws IOException{
		ByteArrayInputStream bais = new ByteArrayInputStream(data);
		DataInputStream dis = new DataInputStream(bais);
		int nodeLen = dis.readInt(), dataLen = dis.readInt();
		
		dis.close();
		bais.close();
	}
	
	private class VOCell implements Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		public Integer identifier;
		public boolean isFinish;
		public DataOfPoint dataOfPoint;
		public String mbrDigest;
		public int[] childIdentifiers;
		public String childDigest;
		public int level;
		public VOCell(){}
		
		public long getVOSize(){
			long ans = 0;
			if(isFinish){
				if(level >= 0){
					ans += mbrDigest.getBytes().length;
					ans += childDigest.getBytes().length;
				}else{
					ans += dataOfPoint.p.getDigest().getBytes().length;
				}
				ans += 4; //level
			}else{
				if(level >= 0){
					ans += mbrDigest.getBytes().length;
					ans += childIdentifiers.length * 4;
				}else{
					ans += dataOfPoint.p.getDigest().getBytes().length;
				}
				ans += 4; //level
			}
			return ans;
		}
		
		public long getVOSizeBOVD(){
			long ans = 0;
			for(int i = 0; i < dataOfPoint.delaunayIds.length; i++){
				ans += Hasher.hashString(dataOfPoint.delaunayIds[i].toString()).getBytes().length;
			}
			ans += dataOfPoint.p.getDigest().getBytes().length;
			ans += 4; // id
			return ans;
		}
		
		public void setLevel(int _level){
			level = _level;
		}
		
		public VOCell(boolean _isResult, DataOfPoint _dataOfPoint, int _level){
			identifier = _dataOfPoint.pid;
			isFinish =_isResult;
			dataOfPoint = _dataOfPoint;
			level = _level;
		} 
		
		public VOCell(boolean _isResult, String digest, int[] _childIdentifiers, int _level){
			isFinish = _isResult;
			mbrDigest = digest;
			childIdentifiers = new int[_childIdentifiers.length];
			for(int i = 0; i < childIdentifiers.length; i++){
				childIdentifiers[i] = _childIdentifiers[i];
			}
			level = _level;
		}
		
		public VOCell(boolean _isResult, String _childDigest, String digest, int _level){
			isFinish = _isResult;
			childDigest = _childDigest;
			mbrDigest = digest;
			level = _level;
		}
		
		public void writeStringArray(DataOutputStream dos, String[][] strs) throws IOException{
			if(strs == null){
				dos.writeInt(0);
				return;
			}
			int len = strs.length;
			dos.writeInt(len);
			for(int i = 0; i < len; i++){
				if(strs[i] == null || strs[i].length == 0){
					dos.writeInt(0);
					continue;
				}
				dos.writeInt(strs[i].length);
				for(int j = 0; j < strs[i].length; j++){
					DataIO.writeString(dos, strs[i][j]);
				}
			}
		}
		
		public String[][] readStringArray(DataInputStream dis) throws IOException{
			int len = dis.readInt();
			if(len == 0)return null;
			String[][] ans = new String[len][];
			for(int i = 0; i < len; i++){
				int m = dis.readInt();
				if(m == 0)continue;
				ans[i] = new String[m];
				for(int j = 0; j < m; j++){
					ans[i][j] = DataIO.readString(dis);
				}
			}
			return ans;
		}
		
		public void writeToFile(DataOutputStream dos) throws IOException{
			
		}
		
		public void readFromFile(DataInputStream dis) throws IOException{
			
		}
	}
	
	public class lineCell{
		public long id1, id2;
		public Line line;
		public String signature;
		public lineCell(){}
		public lineCell(DataOfLine dataOfLine){
			id1 = dataOfLine.lid / DataOfLine.M;
			id2 = dataOfLine.lid % DataOfLine.M;
			line = dataOfLine.line;
			signature = dataOfLine.signature;
		}
		public void generateVeryfyPart(Point q){
			line.GenerateVeryfyPart(new utility.security.Point((long)q.getCoord(0), (long)q.getCoord(1)));
		}
		public boolean verify(Point q){
			return line.ClientVerify(new utility.security.Point((long)q.getCoord(0), (long)q.getCoord(1)));
		}
		
		public long getVOSize(){
			long ans = 0;
			ans += line.getVOSize();
			return ans;
		}
	}
	
	public class dcCell{
		public DistanceCompare dc;
		public dcCell(){}
		public dcCell(utility.security.Point p1, utility.security.Point p2){
			dc = new DistanceCompare(p1, p2);
		}
		public void generateVeryfyPart(Point q){
			dc.GenerateVeryfyPart(new utility.security.Point((long)q.getCoord(0), (long)q.getCoord(1)));
		}
		public boolean verify(Point q){
			return dc.ClientVerify(new utility.security.Point((long)q.getCoord(0), (long)q.getCoord(1)));
		}
		
		public long getVOSize(){
			long ans = 0;
			ans += dc.getVOSize();
			return ans;
		}
	}
	
	public class gfCell{
		public Gfunction gf = null, gf2 = null;
		public String[] ServerReturned, ServerReturned2;
		public boolean isL, isL2;
		public gfCell(){}
		public gfCell(Gfunction _gf, Gfunction _gf2, boolean _isL, boolean _isL2){
			gf = _gf;
			gf2 = _gf2;
			isL = _isL;
			isL2 = _isL2;
		}
		
		public long getVOSize(){
			long ans = 0;
			if(ServerReturned != null){
				ans += ServerReturned.length;
			}
			if(ServerReturned2 != null){
				ans += ServerReturned2.length;
			}
			return ans;
		}
		
		public void setGf(Gfunction _gf, boolean _isL){
			gf = _gf;
			isL = _isL;
		}
		
		public void setGf2(Gfunction _gf, boolean _isL){
			gf2 = _gf;
			isL2 = _isL;
		}
		
		public void generateVeryfyPart(Point p){
			if(gf != null)ServerReturned = gf.GenerateVeryfyPart((long)p.getCoord(0), isL);
			if(gf2 != null)ServerReturned2 = gf2.GenerateVeryfyPart((long)p.getCoord(1), isL2);
		}
		
		public boolean verify(Point p){
			if(!isL){
				try {
					if(gf != null) if(gf.ClientComputed(ServerReturned, gf.U - ((long)p.getCoord(0))).equals(gf.getDigest()) == false)return false;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else{
				try {
					if(gf != null)if(gf.ClientComputed(ServerReturned, ((long)p.getCoord(0)) - gf.L).equals(gf.getDigest()) == false)return false;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(!isL2){
				try {
					if(gf2 != null) if(gf2.ClientComputed(ServerReturned2, gf2.U - ((long)p.getCoord(1))).equals(gf2.getDigest()) == false)return false;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else{
				try {
					if(gf2 != null)if(gf2.ClientComputed(ServerReturned2, ((long)p.getCoord(1)) - gf2.L).equals(gf2.getDigest()) == false)return false;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return true;
		}
	}
}
