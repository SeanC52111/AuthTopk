package spatialindex.rtree;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Set;

import utility.math.BigIntegerUtility;
import utility.security.Paillier;
import utility.security.SeedsGenerater;

public class NSecurityTree {
	private static String filePath;
	public final static BigInteger a = BigIntegerUtility.PRIME_P;
	private static RTree rtree;
	public static Paillier pailliar = new Paillier(true);
	public static BigInteger ZeroOfPailliar = NSecurityTree.pailliar.Encryption(BigInteger.ZERO);
	public static SeedsGenerater seeds = new SeedsGenerater(true);
	NSecurityNode root;
	private static HashMap<Integer, NSecurityNode> NSecurityNodeMap = new HashMap<Integer, NSecurityNode>();

	/**
	 * if this contains a value means it should be load from the file, save (ID,
	 * pos in index file) pairs
	 */
	private static HashMap<Integer, Integer> NSecurityNodeMapPos = new HashMap<Integer, Integer>();
	private static HashMap<Integer, Integer> NSecurityNodeMapLength = new HashMap<Integer, Integer>();

	static int level;

	public NSecurityTree(RTree _rtree) {
		System.out.println("building security info");
		long startTime = System.currentTimeMillis();
		rtree = _rtree;
		buildSecurityTree(_rtree);
		long endTime = System.currentTimeMillis();
		long cpuTime = endTime - startTime;
		System.out.println("build security info finished, time used:" + cpuTime + "ms");
	}

	public NSecurityTree(RTree _rtree, String _filePath) throws IOException {
		rtree = _rtree;
		filePath = _filePath;
		readFromFile(rtree, filePath);
	}

	private void buildSecurityTree(RTree rtree) {
		root = NSecurityNode.buildNSecurityNode(rtree);
		level = root.getLevel();
	}

	public static void saveNSecurityNode(NSecurityNode n, int id) {
		if (n.getLevel() > 1) {
			System.out.println("sNode[" + id + "] saved, lv=" + n.getLevel());
		}
		NSecurityNodeMap.put(new Integer(id), n);
	}

	public static NSecurityNode getNSecurityNode(int id) {
		NSecurityNode snode = NSecurityNodeMap.get(new Integer(id));
		if (snode == null) {
			Integer pos = NSecurityNodeMapPos.get(new Integer(id));
			if (pos == null) {
				return null;
			} else {
				int length = NSecurityNodeMapLength.get(new Integer(id)).intValue();
				//load from file
				try {
					RandomAccessFile rfile = new RandomAccessFile(new File(filePath + ".sdat"), "r");
					rfile.seek(pos.intValue());
					byte[] data = new byte[length];
					rfile.read(data, 0, length);
					//for (int i = 0; i < length; i++) {
					//	data[i] = rfile.readInt();
					//}
					rfile.close();
					snode = new NSecurityNode(data, rtree);
				} catch (FileNotFoundException e) {
					e.printStackTrace();
					return null;
				} catch (IOException e) {
					e.printStackTrace();
					return null;
				}
				//cache it
				saveNSecurityNode(snode, id);
				return snode;
			}
		} else {
			return snode;
		}
	}

	public int getRootEntaValue() {
		return root.getEntaValue();
	}

	/**
	 * auto add "idx" and "dat"
	 * 
	 * @param file
	 * @throws IOException
	 */
	public void writeToFile(String filePath) throws IOException {
		DataOutputStream indexDos = new DataOutputStream(new FileOutputStream(filePath + ".nsidx"));
		DataOutputStream dataDos = new DataOutputStream(new FileOutputStream(filePath + ".nsdat"));
		Set<Integer> keySet = NSecurityNodeMap.keySet();
		int dataPos = 0;
		for (Integer key : keySet) {
			byte[] snodeData = NSecurityNodeMap.get(key).saveToBytes();
			indexDos.writeInt(key.intValue());
			indexDos.writeInt(dataPos);
			dataPos += snodeData.length;
			indexDos.writeInt(snodeData.length);
			dataDos.write(snodeData);
//			for (int i = 0; i < snodeData.length; i++) {
//				dataDos.writeInt(snodeData[i]);
//			}
		}
		indexDos.flush();
		indexDos.close();
		dataDos.flush();
		dataDos.close();
	}

	private void readFromFile(RTree rtree, String filePath) throws IOException {
		DataInputStream indexDis = new DataInputStream(new FileInputStream(filePath + ".sidx"));
		while (indexDis.available() > 0) {
			Integer key = new Integer(indexDis.readInt());
			int pos = indexDis.readInt();
			NSecurityNodeMapPos.put(key, new Integer(pos));
			int dataLength = indexDis.readInt();
			NSecurityNodeMapLength.put(key, new Integer(dataLength));
		}
		indexDis.close();
	}

	@Override
	public String toString() {
		if (root == null) {
			return "root:null";
		}
		return root.toString();
	}
}
