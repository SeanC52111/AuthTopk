/**
 * 
 */
package spatialindex.rtree;

import java.util.ArrayList;

import spatialindex.core.IData;
import spatialindex.core.IEntry;
import spatialindex.core.INode;
import spatialindex.core.IQueryStrategy;
import spatialindex.core.IShape;
import spatialindex.core.IVisitor;
import spatialindex.core.Point;
import spatialindex.core.Region;
import spatialindex.rtree.RTree.Data;

/**
 * @author chenqian
 *
 */
public class BuildVerificationKDTreeStrategy implements IQueryStrategy {
	ArrayList<Integer> ids = null;
	RTree rtree = null;
	KNNCompartor knnc = null;
	IShape query = null;
	IVisitor v = null;
	double dist;
	
	public void LoadKDTree(int s, int e, Node node, IShape query, KNNCompartor knnc, IVisitor v, Region MBR, double dist){
		if(s > e) return;
		IEntry e1 = null;
		if(s == e){
			if(node.m_level == 0){
				e1 = rtree.new Data(node.m_pData[s], node.m_pMBR[s], node.m_pIdentifier[s]);
				v.visitData((IData)e1);
			}else{
				e1 = rtree.readNode(node.m_pIdentifier[s]);
				double mindist = knnc.getMinimumDistance(query, e1);
				double maxdist = knnc.getMaximunDistance(query, e1);
				//if(mindist > dist || maxdist < dist){
				if(mindist > dist){
					Data e2 = rtree.new Data(null, node.m_pMBR[s], -1);
					v.visitData((IData)e2);
				}else{
					ids.add(e1.getIdentifier());
					//LoadKDTree(0, e2.m_children - 1, e2, query, knnc, v, e2.m_nodeMBR, dist);
				}
			}
			return;
		}else{
			e1 = rtree.new Data(null, MBR, -1);
			double mindist = knnc.getMinimumDistance(query, e1);
			double maxdist = knnc.getMaximunDistance(query, e1);
			//if(mindist > dist || maxdist < dist){
			if(mindist > dist){
				v.visitData((IData) e1);
				return;
			}
		}
		int mid = (s + e) >> 1;
		Region mbr1 = new Region(node.m_pMBR[s]), mbr2 = new Region(node.m_pMBR[e]);
		for(int i = s + 1; i <= mid; i++){
			Region.combinedRegion(mbr1, node.m_pMBR[i]);
		}
		for(int i = mid + 1; i < e; i++){
			Region.combinedRegion(mbr2, node.m_pMBR[i]);
		}
		LoadKDTree(s, mid, node, query, knnc, v, mbr1, dist);
		LoadKDTree(mid + 1, e, node, query, knnc, v, mbr2, dist);
	}
	
	/* (non-Javadoc)
	 * @see spatialindex.core.IQueryStrategy#getNextEntry(spatialindex.core.IEntry, int[], boolean[])
	 */
	@Override
	public void getNextEntry(IEntry arg0, int[] arg1, boolean[] arg2) {
		// TODO Auto-generated method stub
		Node node = (Node) arg0;
		LoadKDTree(0, node.m_children - 1, node, query, knnc, v, node.m_nodeMBR, dist);
		arg2[0] = true;
		if(ids.size() == 0){
			arg2[0] = false;
		}else{
			arg1[0] = ids.remove(0).intValue();
		}
	}

	public BuildVerificationKDTreeStrategy(RTree rtree, IShape query, IVisitor v, double dist){
		this.rtree = rtree;
		this.knnc = new KNNCompartor();
		this.query = query;
		this.v = v;
		this.dist = dist;
		ids = new ArrayList<Integer>();
	}
	
	class KNNCompartor {

		public double getMinimumDistance(IShape query, IEntry e) {
			// TODO Auto-generated method stub
			IShape s = e.getShape();
			return query.getMinimumDistance(s);
		}
		
		public double getMaximunDistance(IShape query, IEntry e){
			Region region = e.getShape().getMBR();
			double ans = 0.0;
			double x1 = region.getLow(0);
			double y1 = region.getLow(1);
			double x2 = region.getHigh(0);
			double y2 = region.getHigh(1);
			ans = Math.max(ans, query.getMinimumDistance(new Point(new double[] {x1, y1})));
			ans = Math.max(ans, query.getMinimumDistance(new Point(new double[] {x1, y2})));
			ans = Math.max(ans, query.getMinimumDistance(new Point(new double[] {x2, y1})));
			ans = Math.max(ans, query.getMinimumDistance(new Point(new double[] {x2, y2})));
			return ans;
		}
	}
}
