package utility.Compare;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import utility.security.Point;

public class DataOfPoint{
	public Point p;
	public Long[] delaunayIds = null;
	
	public DataOfPoint(){
		p = new Point();
		delaunayIds = new Long[0];
	}
	
	public DataOfPoint(Point _p, Long[] _ids){
		p = _p;
		delaunayIds = _ids;
	}
	
	public DataOfPoint(byte[] buf){
		try {
			loadFromBytes(buf);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public byte[] writeToBytes() throws IOException{
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);
		p.writeToFile(dos);
		dos.writeInt(delaunayIds.length);
		for(int i = 0 ; i < delaunayIds.length; i++){
			dos.writeLong(delaunayIds[i]);
		}		
		return baos.toByteArray();
	}
	
	public void load(DataInputStream dis){
		p.readFromFile(dis);
		int len;
		try {
			len = dis.readInt();
			delaunayIds = new Long[len];
			for(int i = 0 ; i < len; i++){
				delaunayIds[i] = dis.readLong();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void loadFromBytes(byte[] buffer) throws IOException{
		DataInputStream dis = new DataInputStream(new ByteArrayInputStream(buffer));
		p.readFromFile(dis);
		int len = dis.readInt();
		delaunayIds = new Long[len];
		for(int i = 0 ; i < len; i++){
			delaunayIds[i] = dis.readLong();
		}
		dis.close();
	}
}