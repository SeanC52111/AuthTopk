package spatialindex.rtree;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.RandomAccessFile;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import mesh.Delaunay;

import utility.geo.Line;
import utility.math.BigIntegerUtility;
import utility.security.Paillier;
import utility.security.Point;
import utility.security.SeedsGenerater;

public class GSecurityTree {
	private static String filePath;
	public final static BigInteger a = BigIntegerUtility.PRIME_P;
	private static RTree rtree;
	public static Paillier pailliar = new Paillier(true);
	public static SeedsGenerater seeds = new SeedsGenerater(true);
	GSecurityNode root;
	private static HashMap<Integer, GSecurityNode> GSecurityNodeMap = new HashMap<Integer, GSecurityNode>();

	/**
	 * if this contains a value means it should be load from the file, save (ID,
	 * pos in index file) pairs
	 */
	private static HashMap<Integer, Integer> GSecurityNodeMapPos = new HashMap<Integer, Integer>();
	private static HashMap<Integer, Integer> GSecurityNodeMapLength = new HashMap<Integer, Integer>();
	public HashMap<Integer, ArrayList<Integer>> Delaunayids = new HashMap<Integer, ArrayList<Integer>>();
	public HashMap<Integer, ArrayList<Line>> Delaunaylines = new HashMap<Integer, ArrayList<Line>>();
	static int level;
	public void buildDelaunay(){
		ArrayList<float[]> points = new ArrayList<float[]>();	
		ArrayList<Integer> idmap = new ArrayList<Integer>();
		try {
			String line = null;
			LineNumberReader lr = new LineNumberReader(new FileReader(GSecurityTree.filePath));
			try {
				while((line = lr.readLine()) != null){
					String[] num = line.split(" ");
					idmap.add(Integer.parseInt(num[0]));
					float[] point = new float[2];
					point[0] = Float.parseFloat(num[1]);
					point[1] = Float.parseFloat(num[2]);
					points.add(point);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Delaunay delaunay = new Delaunay(points.toArray(new float[0][0]));
		for(int i = 0; i < points.size(); i++){
			int[] pid = delaunay.getLinked(i + 1);
			ArrayList<Integer> tmp = new ArrayList<Integer>();
			ArrayList<Line> lines = new ArrayList<Line>();
			Point pPoint = new Point((int)points.get(i)[0], (int)points.get(i)[1]);
			for(int j = 0; j < pid.length && pid[j] > 0; j++){
				tmp.add(idmap.get(pid[j] - 1));
				Point qPoint = new Point((int)points.get(pid[j] - 1)[0], (int)points.get(pid[j] - 1)[1]);
				Line line = new Line(pPoint, qPoint);
				lines.add(line);
			}
			Delaunayids.put(idmap.get(i), tmp);
		}
	}
	
	public GSecurityTree(RTree _rtree) {
		System.out.println("building security info");
		long startTime = System.currentTimeMillis();
		rtree = _rtree;
		buildDelaunay();
		buildSecurityTree(_rtree);
		long endTime = System.currentTimeMillis();
		long cpuTime = endTime - startTime;
		System.out.println("build security info finished, time used:" + cpuTime + "ms");
	}

	public GSecurityTree(RTree _rtree, String _filePath) throws IOException {
		rtree = _rtree;
		filePath = _filePath;
		readFromFile(rtree, filePath);
	}

	private void buildSecurityTree(RTree rtree) {
		root = GSecurityNode.buildGSecurityNode(rtree);
		level = root.getLevel();
	}

	public static void saveGSecurityNode(GSecurityNode n, int id) {
		if (n.getLevel() > 1) {
			System.out.println("sNode[" + id + "] saved, lv=" + n.getLevel());
		}
		GSecurityNodeMap.put(new Integer(id), n);
	}

	public static GSecurityNode getGSecurityNode(int id) {
		GSecurityNode snode = GSecurityNodeMap.get(new Integer(id));
		if (snode == null) {
			Integer pos = GSecurityNodeMapPos.get(new Integer(id));
			if (pos == null) {
				return null;
			} else {
				int length = GSecurityNodeMapLength.get(new Integer(id)).intValue();
				//load from file
				try {
					RandomAccessFile rfile = new RandomAccessFile(new File(filePath + ".sdat"), "r");
					rfile.seek(pos.intValue());
					byte[] data = new byte[length];
					rfile.read(data, 0, length);
					//for (int i = 0; i < length; i++) {
					//	data[i] = rfile.readInt();
					//}
					rfile.close();
					snode = new GSecurityNode(data, rtree);
				} catch (FileNotFoundException e) {
					e.printStackTrace();
					return null;
				} catch (IOException e) {
					e.printStackTrace();
					return null;
				}
				//cache it
				saveGSecurityNode(snode, id);
				return snode;
			}
		} else {
			return snode;
		}
	}

	public int getRootEntaValue() {
		return root.getEntaValue();
	}

	/**
	 * auto add "idx" and "dat"
	 * 
	 * @param file
	 * @throws IOException
	 */
	public void writeToFile(String filePath) throws IOException {
		DataOutputStream indexDos = new DataOutputStream(new FileOutputStream(filePath + ".nsidx"));
		DataOutputStream dataDos = new DataOutputStream(new FileOutputStream(filePath + ".nsdat"));
		Set<Integer> keySet = GSecurityNodeMap.keySet();
		int dataPos = 0;
		for (Integer key : keySet) {
			byte[] snodeData = GSecurityNodeMap.get(key).saveToBytes();
			indexDos.writeInt(key.intValue());
			indexDos.writeInt(dataPos);
			dataPos += snodeData.length;
			indexDos.writeInt(snodeData.length);
			dataDos.write(snodeData);
//			for (int i = 0; i < snodeData.length; i++) {
//				dataDos.writeInt(snodeData[i]);
//			}
		}
		indexDos.flush();
		indexDos.close();
		dataDos.flush();
		dataDos.close();
	}

	private void readFromFile(RTree rtree, String filePath) throws IOException {
		DataInputStream indexDis = new DataInputStream(new FileInputStream(filePath + ".sidx"));
		while (indexDis.available() > 0) {
			Integer key = new Integer(indexDis.readInt());
			int pos = indexDis.readInt();
			GSecurityNodeMapPos.put(key, new Integer(pos));
			int dataLength = indexDis.readInt();
			GSecurityNodeMapLength.put(key, new Integer(dataLength));
		}
		indexDis.close();
	}

	@Override
	public String toString() {
		if (root == null) {
			return "root:null";
		}
		return root.toString();
	}
}
