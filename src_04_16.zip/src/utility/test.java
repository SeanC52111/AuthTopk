package utility;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

import utility.Compare.DistanceCompare;
import utility.geo.Line;
import utility.math.BigIntegerUtility;
import utility.security.Paillier;
import utility.security.Point;

import mesh.Delaunay;
import mesh.MPolygon;
import mesh.Voronoi;


public class test {
	
	static float[][] loadpoint(String path){
		ArrayList<float[]> ans = new ArrayList<float[]>();
		try {
			String line = null;
			LineNumberReader lr = new LineNumberReader(new FileReader(path));
			try {
				while((line = lr.readLine()) != null){
					String[] num = line.split(" ");
					float[] point = new float[2];
					point[0] = Float.parseFloat(num[0]);
					point[1] = Float.parseFloat(num[1]);
					ans.add(point);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return (float[][])ans.toArray(new float[ans.size()][]);
	}
	
	public static void printarray(float[][] a){
		for(int i = 0; i < a.length; i++){
			for(int j = 0; j < a[i].length; j++){
				System.out.print(a[i][j] + " ");
			}
			System.out.println("");
		}
	}
	
	public static void main(String args[]) throws IOException, NoSuchAlgorithmException{
		long start = System.currentTimeMillis();
		DistanceCompare distanceCompare = new DistanceCompare(new Point(66500, 14866), new Point(14009, 14581));
		distanceCompare.GenerateVeryfyPart(new Point(50000, 50000));
		System.out.println("distanceCompare construction time consume : " + (System.currentTimeMillis() - start));
		start = System.currentTimeMillis();
		for(int i = 0; i < 100; i++){
			if(distanceCompare.ClientVerify(50000, 50000)){
				//System.out.println("Pass verification!");
			}else {
				System.err.println("Fail verification!");
			}
		}
		System.out.println("Distance Compare time consume : " + (System.currentTimeMillis() - start));
		start = System.currentTimeMillis();
		Line line = new Line(new Point(66500, 14866), new Point(14009, 14581));
		line.GenerateVeryfyPart(new Point(50000, 50000));
		System.out.println("Line-based construction time consume : " + (System.currentTimeMillis() - start));
		start = System.currentTimeMillis();
		for(int i = 0 ; i < 100; i ++){
			if(line.ClientVerify(50000, 50000)){
				//System.out.println("Pass verification!");
			}else {
				System.err.println("Fail verification!");
			}
		}
		System.out.println("Line-based verification time consume : " + (System.currentTimeMillis() - start));
		Paillier paillier = new Paillier(true);
		BigInteger message = new BigInteger("123");
		BigInteger ciphertext1 = paillier.Encryption(message);
		System.out.println("ciphertext1 : " + ciphertext1);
		BigInteger ciphertext2 = paillier.Encryption(message.add(paillier.GetEulorTotient()));
		System.out.println("ciphertext2 : " + ciphertext2);
//		start = System.currentTimeMillis();
//		Point pPoint = new Point(1, 1);
//		pPoint.buildByPaillier();
//		System.out.println("time consume : " + (System.currentTimeMillis() - start));
//		Scanner in = new Scanner(new BufferedInputStream(System.in));
//		System.out.println("please input the filename you want to read:");
//		String filein = in.nextLine();
//		float [][] points = loadpoint(filein);
//		Voronoi vor = new Voronoi(points);
//		Delaunay del = new Delaunay(points);
//		//testofdel tt = new testofdel(points);
//		//System.err.println(tt.linkCount);
//		MPolygon[] poly = vor.getRegions();
//		for(int i = 0; i < poly.length; i++){
//			float[][] p = poly[i].getCoords();
//			for(int j = 0 ; j < p.length; j++){
//				System.out.print("(" + p[j][0]+ ", " + p[j][1] + ") ");
//			}System.out.println("");
//			//printarray(p);
//		}
//		System.out.println("========end of poly of voronoi==========");
//		for(int i = 0; i < points.length; i++){
//			int[] p = del.getLinked(i + 1);
//			System.out.print(i + " :");
//			for(int j = 0; j < p.length && p[j] > 0; j++){
//				System.out.print(" " + (p[j] - 1));
//			}System.out.println();
//		}
//		System.out.println("========end of poly of delaunay==========");
//		
	}
}
