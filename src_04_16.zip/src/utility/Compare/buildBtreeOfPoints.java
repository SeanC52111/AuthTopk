package utility.Compare;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;


import mesh.Delaunay;

import utility.security.Point;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;
/*
 * 
 * @author qchen
 * */
public class buildBtreeOfPoints {
	public static boolean DEBUG = true;
	public static boolean ISCAR = false;
	public static long SCALE = 100000;
	public static String filename = "database/PointsData.NE";
	public RecordManager recmanOfPoint;
	public PrimaryTreeMap<Long, byte[]> btOfPoint;
	public void loadData() throws IOException{
		ArrayList<float[]> points = new ArrayList<float[]>();	
		ArrayList<Integer> idmap = new ArrayList<Integer>();
		//PrintWriter pw = new PrintWriter(new BufferedOutputStream(new FileOutputStream(new File(filename))));
		try {
			String line = null;
			LineNumberReader lr = new LineNumberReader(new FileReader("source/NE.dat"));
			try {
				while((line = lr.readLine()) != null){
					String[] num = line.split(" ");
					idmap.add(Integer.parseInt(num[1]));
					float[] point = new float[2];
					point[0] = Float.parseFloat(num[2]);
					point[1] = Float.parseFloat(num[3]);
					if(ISCAR){
						point[0] = (int)(point[0] * SCALE);
						point[1] = (int)(point[1] * SCALE);
					}
					points.add(point);
					//if(DEBUG) System.err.println();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Delaunay delaunay = new Delaunay(points.toArray(new float[0][0]));
		for(int i = 0; i < points.size(); i++){
			int[] pid = delaunay.getLinked(i + 1);
			ArrayList<Long> tmp = new ArrayList<Long>();
			Point pPoint = new Point((int)points.get(i)[0], (int)points.get(i)[1]);
			//pw.print((long)idmap.get(i) + " " + pPoint.x + " " + pPoint.y);
			for(int j = 0; j < pid.length && pid[j] > 0; j++){
				tmp.add((long)idmap.get(pid[j] - 1));
				//pw.print(" " + (long)idmap.get(pid[j] - 1));
			}
			//pw.println();
			pPoint.buildByPaillier();
			DataOfPoint data = new DataOfPoint(pPoint, tmp.toArray(new Long[0]));
			btOfPoint.put((long)idmap.get(i), data.writeToBytes());
			//Data testData = new Data();
			//testData.loadFromBytes(bt.get((long)idmap.get(i)));
			if(i % 100 == 0)recmanOfPoint.commit();
//			if(DEBUG){
//				//recman.commit();
//				System.err.println(i + " have finished");
//			}
		}
		//pw.flush();
		//pw.close();
		recmanOfPoint.commit();
	}
	
	public buildBtreeOfPoints(boolean needLoad) throws IOException{
		recmanOfPoint = RecordManagerFactory.createRecordManager(filename);
		btOfPoint = recmanOfPoint.treeMap("treemap");
		if(needLoad){
			loadData();
		}
	}
	
	public static void main(String[] args) throws IOException{
		long start = System.currentTimeMillis();
		buildBtreeOfPoints bTree = new buildBtreeOfPoints(false); 
		System.out.println("Time consume: " + (System.currentTimeMillis() - start));
		Scanner in = new Scanner(System.in);
		while(true){
			System.out.println("input id below:");
			long id = in.nextLong();
			byte[] str = bTree.btOfPoint.find(id);
			DataOfPoint data = new DataOfPoint();
			data.loadFromBytes(str);
			System.out.println(id + " : " + data.p.x + " " + data.p.y + " dels : ");
			for(long x : data.delaunayIds){
				System.out.print(x + " ");
			}
			System.out.println("");
		}
	}
}


