/**
 * 
 */
package spatialindex.rtree;

import java.math.BigInteger;
import java.util.ArrayList;

import utility.SecurityUtility;
import utility.security.Gfunction;
import utility.security.IVo;

/**
 * @author qchen
 *
 */
public class ODGfunction implements IVo {

	/* (non-Javadoc)
	 * @see utility.security.IVo#ClientVerify(int, int)
	 */
	
	Gfunction gf1, gf2;
	long L = 0, U = (long)1 << 32;
	int base = 10;
	int a, b;
	public ODGfunction(int a, int b, int x, int y) {
		// TODO Auto-generated constructor stub
		this.a = a;
		this.b = b;
		gf1 = null;
		gf2 = null;
		if(a == 0){
			if(b == 0){
				gf1 = new Gfunction(x, base, L, U);
				gf2 = new Gfunction(y, base, L, U);
			}else if(b == 1){
				gf1 = new Gfunction(x, base, L, U);
			}else{
				gf1 = new Gfunction(x, base, L, U);
				gf2 = new Gfunction(y, base, L, U);
			}
		}else if(a == 1){
			if(b == 0){
				gf2 = new Gfunction(y, base, L, U);
			}else if(b == 2){
				gf2 = new Gfunction(y, base, L, U);
			}
		}else {
			if(b == 0){
				gf1 = new Gfunction(x, base, L, U);
				gf2 = new Gfunction(y, base, L, U);
			}else if(b == 1){
				gf1 = new Gfunction(x, base, L, U);
			}else{
				gf1 = new Gfunction(x, base, L, U);
				gf2 = new Gfunction(y, base, L, U);
			}
		}
	}

	public void GenerateVeryfyPart(int q_x, int q_y){
		if(gf1 != null)gf1.GenerateVeryfyPart(q_x);
		if(gf2 != null)gf2.GenerateVeryfyPart(q_y);
	}
	@Override
	public boolean ClientVerify(int q_x, int q_y) {
		// TODO Auto-generated method stub
		boolean res1 = true, res2 = true;
		if(a == 0){
			if(b == 0){
				res1 = gf1.ClientVerifyL(L - q_x);
				res2 = gf2.ClientVerifyL(L - q_y);
			}else if(b == 1){
				res1 = gf1.ClientVerifyL(L - q_x);
			}else{
				res1 = gf1.ClientVerifyL(L - q_x);
				res2 = gf2.ClientVerifyU(U - q_y);
			}
		}else if(a == 1){
			if(b == 0){
				res2 = gf2.ClientVerifyL(L - q_y);
			}else if(b == 2){
				res2 = gf2.ClientVerifyU(U - q_y);
			}else{
				res1 = false;
				res2 = false;
			}
		}else {
			if(b == 0){
				res1 = gf1.ClientVerifyU(U - q_x);
				res2 = gf2.ClientVerifyL(L - q_y);
			}else if(b == 1){
				res1 = gf1.ClientVerifyU(U - q_x);
			}else{
				res1 = gf1.ClientVerifyU(U - q_x);
				res2 = gf2.ClientVerifyU(U - q_y);
			}
		}
		if(res1 && res2)return true;
		return false;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ODGfunction odGfunction = new ODGfunction(0, 0, 5000, 5000);
		odGfunction.GenerateVeryfyPart(1000, 1000);
		if(odGfunction.ClientVerify(1000, 1000)){
			System.out.println("Pass!");
		}else{
			System.err.println("Fail!");
		}
	}

	/* (non-Javadoc)
	 * @see utility.security.IVo#getHashcode()
	 */
	@Override
	public String getHashcode() {
		// TODO Auto-generated method stub
		if(gf1 == null && gf2 == null)return null;
		ArrayList<BigInteger> hashfactors = new ArrayList<BigInteger>();
		if(gf1 != null){
			hashfactors.add(new BigInteger(gf1.HashCode(), 16));
		}
		if(gf2 != null){
			hashfactors.add(new BigInteger(gf2.HashCode(), 16));
		}
		return SecurityUtility.computeHashValue(hashfactors.toArray(new BigInteger[0]));
	}

}
