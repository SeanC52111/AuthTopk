package utility.geo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.math.BigInteger;

import spatialindex.rtree.NSecurityTree;
import utility.SecurityUtility;
import utility.security.Gfunction;
import utility.security.IVo;
import utility.security.Paillier;
import utility.security.Point;

public class Line implements IVo{
	Point pL, pH;
	Point o_pL, o_pH; 
	Point farL_pL, farL_pH;
	Point farR_pL, farR_pH;
	BigInteger x1y2_y1x2_l, x1y2_y1x2_r;
	public static Paillier pailliar = NSecurityTree.pailliar;
	public BigInteger g_l_x, g_l_y, g_r_x, g_r_y;
	public BigInteger n_g_l_x, n_g_l_y, n_g_r_x, n_g_r_y;
	Gfunction gf;
	public Line(){
		
	}
	
	public Line(Point _pL, Point _pH){
		pL = new Point(_pL);
		pH = new Point(_pH);
		init();
	}
	
	public Line(int[] _pL, int[] _pH){
		pL = new Point(_pL);
		pH = new Point(_pH);
		init();
	}
	
	public void init(){
		o_pL = new Point((pL.x + pH.x) / 2, (pL.y + pH.y) / 2);
		Point vertical = new Point(pH.y - pL.y, pL.x - pH.x);
		o_pH = new Point(o_pL);
		o_pH.Add(vertical);
		Point[] far_pL = new Point[4], far_pH = new Point[4];
		long[] area = new long[4];
		far_pL[0] = new Point(0, 0);
		far_pL[1] = new Point((1 << 31) - 1, 0);
		far_pL[2] = new Point(0, (1 << 31) - 1);
		far_pL[3] = new Point((1 << 31) - 1, (1 << 31) - 1);
		long min = (long)1 << 60, max = -(long) 1 << 60;
		for(int i = 0; i < 4; i++ ){
			far_pH[i] = new Point(far_pL[i]);
			far_pH[i].Add(vertical);
			area[i] = Point.Areax2(far_pL[i], far_pH[i], o_pL);
			if(min > area[i]){
				farL_pL = far_pL[i];
				farL_pH = far_pH[i];
				min = area[i];
			}
			if(max < area[i]){
				farR_pL = far_pL[i];
				farR_pH = far_pH[i];
				max = area[i];
			}
		}
		gf = new Gfunction(0, 10, min, max);
		init_paillier();
	}
	
	void init_paillier(){
		BigInteger x1 = new BigInteger(new Long(farL_pL.x).toString());
		BigInteger y1 = new BigInteger(new Long(farL_pL.y).toString());
		BigInteger x2 = new BigInteger(new Long(farL_pH.x).toString());
		BigInteger y2 = new BigInteger(new Long(farL_pH.y).toString());
		BigInteger b_l_x = x1.subtract(x2);
		if(b_l_x.signum() < 0){
			g_l_x = pailliar.EncryptionWithoutR(b_l_x.add(pailliar.GetEulorTotient()));
			n_g_l_x = pailliar.EncryptionWithoutR(b_l_x.negate());
		}else{
			g_l_x = pailliar.EncryptionWithoutR(b_l_x);
			n_g_l_x = pailliar.EncryptionWithoutR(b_l_x.negate().add(pailliar.GetEulorTotient()));
		}
		BigInteger b_l_y = y2.subtract(y1);
		if(b_l_y.signum() < 0){
			g_l_y = pailliar.EncryptionWithoutR(b_l_y.add(pailliar.GetEulorTotient()));
			n_g_l_y = pailliar.EncryptionWithoutR(b_l_y.negate());
		}else{
			g_l_y = pailliar.EncryptionWithoutR(b_l_y);
			n_g_l_y = pailliar.EncryptionWithoutR(b_l_y.negate().add(pailliar.GetEulorTotient()));
		}
		
		x1y2_y1x2_l = x1.multiply(y2).subtract(y1.multiply(x2));
		
		x1 = new BigInteger(new Long(farR_pL.x).toString());
		y1 = new BigInteger(new Long(farR_pL.y).toString());
		x2 = new BigInteger(new Long(farR_pH.x).toString());
		y2 = new BigInteger(new Long(farR_pH.y).toString());
		
		BigInteger b_r_x = x1.subtract(x2);
		if(b_r_x.signum() < 0){
			g_r_x = pailliar.EncryptionWithoutR(b_r_x.add(pailliar.GetEulorTotient()));
			n_g_r_x = pailliar.EncryptionWithoutR(b_r_x.negate());
		}else{
			g_r_x = pailliar.EncryptionWithoutR(b_r_x);
			n_g_r_x = pailliar.EncryptionWithoutR(b_r_x.negate().add(pailliar.GetEulorTotient()));
		}
		BigInteger b_r_y = y2.subtract(y1);
		if(b_r_y.signum() < 0){
			g_r_y = pailliar.EncryptionWithoutR(b_r_y.add(pailliar.GetEulorTotient()));
			n_g_r_y = pailliar.EncryptionWithoutR(b_r_y.negate());
		}else{
			g_r_y = pailliar.EncryptionWithoutR(b_r_y);
			n_g_r_y = pailliar.EncryptionWithoutR(b_r_y.negate().add(pailliar.GetEulorTotient()));
		}
		x1y2_y1x2_r = x1.multiply(y2).subtract(y1.multiply(x2));
	}
	
	public void GenerateVeryfyPart(Point Q){
		if(o_pL == null || o_pH == null){
			o_pL = new Point((pL.x + pH.x) / 2, (pL.y + pH.y) / 2);
			Point vertical = new Point(pH.y - pL.y, pL.x - pH.x);
			o_pH = new Point(o_pL);
			o_pH.Add(vertical);
		}
		long area = Point.Areax2(o_pL, o_pH, Q.doublePoint());
		//init_paillier();
		gf.GenerateVeryfyPart(-area);
	}
	
	public boolean ClientVerifyU(Point Q){
		//long start = System.currentTimeMillis();
		long area = Point.Areax2(farR_pL, farR_pH, Q);
		BigInteger b_area = new BigInteger(new Long(area).toString());
		
		BigInteger tmp2 = b_area.add(x1y2_y1x2_r), tmpy, tmpx, tmp1, diff;
		//start = System.currentTimeMillis();
		if(tmp2.signum() < 0){
			tmpy = n_g_r_y.modPow(new BigInteger(new Long(Q.x).toString()), pailliar.nsquare);
			tmpx = n_g_r_x.modPow(new BigInteger(new Long(Q.y).toString()), pailliar.nsquare);
			tmp1 = tmpy.multiply(tmpx).mod(pailliar.nsquare);
			//start = System.currentTimeMillis();
			//diff = pailliar.GetG().modPow(tmp2.negate(), pailliar.nsquare);
			diff = pailliar.EncryptionWithoutR(tmp2.negate());
			//System.out.println("diff : " + (System.currentTimeMillis() - start));
		}else{
			tmpy = g_r_y.modPow(new BigInteger(new Long(Q.x).toString()), pailliar.nsquare);
			tmpx = g_r_x.modPow(new BigInteger(new Long(Q.y).toString()), pailliar.nsquare);
			tmp1 = tmpy.multiply(tmpx).mod(pailliar.nsquare);
			diff = pailliar.EncryptionWithoutR(tmp2);
			//diff = pailliar.GetG().modPow(tmp2, pailliar.nsquare);
		}		
	//	System.out.println("encryption time consume : " + (System.currentTimeMillis() - start));
//		if(tmp1.equals(diff) == false){  
//			System.err.println("tmp : " + tmp1);
//			System.err.println("diff : " + diff);
//			return false;
//		}
		//System.out.println("area calc time : " + (System.currentTimeMillis() - start));
		return gf.ClientVerifyU(area);
	}
	
	public boolean ClientVerifyL(Point Q){
		long area = Point.Areax2(farL_pL, farL_pH, Q);
		BigInteger b_area = new BigInteger(new Long(-area).toString());
		BigInteger tmp2 = b_area.subtract(x1y2_y1x2_l), tmpy, tmpx, tmp1, diff;
		//start = System.currentTimeMillis();
		if(tmp2.signum() < 0){
			tmpy = g_l_y.modPow(new BigInteger(new Long(Q.x).toString()), pailliar.nsquare);
			tmpx = g_l_x.modPow(new BigInteger(new Long(Q.y).toString()), pailliar.nsquare);
			tmp1 = tmpy.multiply(tmpx).mod(pailliar.nsquare);
			//diff = pailliar.GetG().modPow(tmp2.negate(), pailliar.nsquare);
			diff = pailliar.EncryptionWithoutR(tmp2.negate());
		}else{
			tmpy = n_g_l_y.modPow(new BigInteger(new Long(Q.x).toString()), pailliar.nsquare);
			tmpx = n_g_l_x.modPow(new BigInteger(new Long(Q.y).toString()), pailliar.nsquare);
			tmp1 = tmpy.multiply(tmpx).mod(pailliar.nsquare);
			diff = pailliar.EncryptionWithoutR(tmp2);
			//diff = pailliar.GetG().modPow(tmp2, pailliar.nsquare);
		}		
	//	System.out.println("encryption time consume : " + (System.currentTimeMillis() - start));
		if(tmp1.equals(diff) == false){  
			System.err.println("tmp : " + tmp1);
			System.err.println("diff : " + diff);
			return false;
		}
		return gf.ClientVerifyL(area);
	}
	
	BigInteger readBigInteger(DataInputStream dis){
		int len;
		try {
			len = dis.readInt();
			byte[] data = new byte[len];
			dis.read(data, 0, len);
			return new BigInteger(data);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	void writeBigInteger(BigInteger bigInteger, DataOutputStream dos){
		byte[] data = bigInteger.toByteArray();
		try {
			dos.writeInt(data.length);
			dos.write(data);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	void writeToFileOfPaillier(DataOutputStream dos){
		writeBigInteger(g_l_x, dos);
		writeBigInteger(g_l_y, dos);
		writeBigInteger(g_r_x, dos);
		writeBigInteger(g_r_y, dos);
		writeBigInteger(n_g_l_x, dos);
		writeBigInteger(n_g_l_y, dos);
		writeBigInteger(n_g_r_x, dos);
		writeBigInteger(n_g_r_y, dos);
		writeBigInteger(x1y2_y1x2_l, dos);
		writeBigInteger(x1y2_y1x2_r, dos);
	}
	
	public void writeToFile(DataOutputStream dos){
		try {
			writeToFileOfPaillier(dos);
			dos.writeLong(pL.x);
			dos.writeLong(pL.y);
			dos.writeLong(pH.x);
			dos.writeLong(pH.y);
			dos.writeLong(farL_pL.x);
			dos.writeLong(farL_pL.y);
			dos.writeLong(farL_pH.x);
			dos.writeLong(farL_pH.y);
			dos.writeLong(farR_pL.x);
			dos.writeLong(farR_pL.y);
			dos.writeLong(farR_pH.x);
			dos.writeLong(farR_pH.y);
			gf.writeToFile(dos);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	void readFromFileOfPaillier(DataInputStream dis){
		g_l_x = readBigInteger(dis);
		g_l_y = readBigInteger(dis);
		g_r_x = readBigInteger(dis);
		g_r_y = readBigInteger(dis);
		n_g_l_x = readBigInteger(dis);
		n_g_l_y = readBigInteger(dis);
		n_g_r_x = readBigInteger(dis);
		n_g_r_y = readBigInteger(dis);
		x1y2_y1x2_l = readBigInteger(dis);
		x1y2_y1x2_r = readBigInteger(dis);
	}
	
	public static int seekLenOfPaillier(DataInputStream dis){
		int ans = 0;
		for(int i = 0; i < 10; i++){
			int len;
			try {
				len = dis.readInt();
				dis.skipBytes(len);
				ans += 4 + len;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return ans;
	}
	public static int seekLen(DataInputStream dis){
		int ans = 0;
		try {
			ans += seekLenOfPaillier(dis);
			ans += 6 * (8 + 8);
			dis.skipBytes(6 * (8 + 8));
			ans += Gfunction.seekLen(dis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ans;
	}
	
	public void readFromFile(DataInputStream dis){
		try {
			readFromFileOfPaillier(dis);
			pL = new Point(dis.readLong(), dis.readLong());
			pH = new Point(dis.readLong(), dis.readLong());
			farL_pL = new Point(dis.readLong(), dis.readLong());
			farL_pH = new Point(dis.readLong(), dis.readLong());
			farR_pL = new Point(dis.readLong(), dis.readLong());;
			farR_pH = new Point(dis.readLong(), dis.readLong());
			gf = new Gfunction();
			gf.readFromFile(dis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args){
		int times = 1;
		Line l = new Line(new int[]{5, 5}, new int[]{4, 4});
		Point Q = new Point (10, 10);
		System.out.println("area: " + Point.Areax2(l.o_pL, l.o_pH, Q));
		l.GenerateVeryfyPart(Q);
		long start = System.currentTimeMillis(), cputime;	
		for(int i = 0; i < times; i++){
			if(l.ClientVerifyU(Q.doublePoint()) || l.ClientVerifyL(Q.doublePoint())){
				//System.out.println("Pass verification");
			}else{
				System.out.println("fail verification");
			}
		}
		cputime = System.currentTimeMillis() - start;
		System.out.println("Pass verification " + times + " consume cputime " + cputime + "ms.");
	}

	@Override
	public boolean ClientVerify(int _q_x, int _q_y) {
		// TODO Auto-generated method stub
		long q_x = 2 * _q_x;
		long q_y = 2 * _q_y;
		//long start = System.currentTimeMillis(); 
		boolean res = (ClientVerifyU(new Point(q_x, q_y)) || ClientVerifyL(new Point(q_x, q_y)));
		//System.out.println("time : " + (System.currentTimeMillis() - start));
		return res;
	}

	/* (non-Javadoc)
	 * @see utility.security.IVo#getHashcode()
	 */
	@Override
	public String getHashcode() {
		// TODO Auto-generated method stub
		return SecurityUtility.computeHashValue(new BigInteger[]{
				new BigInteger(gf.HashCode(), 16),
				x1y2_y1x2_l,
				x1y2_y1x2_r,
				g_l_x,
				g_l_y,
				g_r_x,
				g_r_y,
				g_l_x,
				g_l_y,
				g_r_x,
				g_r_y,
				n_g_l_x,
				n_g_l_y,
				n_g_r_x,
				n_g_r_y
		});
	}
}
