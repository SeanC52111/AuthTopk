package spatialindex.rtree;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;

import spatialindex.core.Region;
import utility.SecurityUtility;
import utility.security.Point;

/**
 * every NSecurityNode has its correspond RTree Node, and can only be constructed
 * by "NSecurityNode buildNSecurityNode(RTree rTree)"
 * 
 * @author qchen
 * modified by qchen
 * 
 */
public class NSecurityNode {

	private static int DIMENSION;

	private final ArrayList<Integer> childAttrHashValues = new ArrayList<Integer>();

	private final ArrayList<Integer> childGValues = new ArrayList<Integer>();
	

	//private final ArrayList<NSecurityNode> childNodes = new ArrayList<NSecurityNode>();

	private Node correspondNode;

	private int correspondNodeID;

	private int entaValue;

	private int gValue;

	private int level = -1;
	
	public NSecurityNode() {

	}

	/**
	 * load from integer data
	 * 
	 * @param data
	 * @param rtree
	 */
	public NSecurityNode(byte[] data, RTree rTree) {
		NSecurityNode.DIMENSION = rTree.m_dimension;
		DataInputStream DIS = new DataInputStream(new ByteArrayInputStream(data));
		/*int pos = 0;
		int count = data[pos];
		pos++;
		for (int i = 0; i < count; i++) {
			childAttrHashValues.add(new Integer(data[pos]));
			pos++;
		}
		count = data[pos];
		pos++;
		for (int i = 0; i < count; i++) {
			childGValues.add(new Integer(data[pos]));
			pos++;
		}
		entaValue = data[pos];
		pos++;
		gValue = data[pos];
		pos++;
		level = data[pos];
		pos++;
		correspondNodeID = data[pos];
		pos++;*/
		
		try {
			int count = DIS.readInt();
			for (int i = 0; i < count; i++) {
				childAttrHashValues.add(new Integer(DIS.readInt()));
			}
			count = DIS.readInt();
			for (int i = 0; i < count; i++) {
				childGValues.add(new Integer(DIS.readInt()));
			}
			entaValue = DIS.readInt();
			gValue = DIS.readInt();
			level = DIS.readInt();
			correspondNodeID = DIS.readInt();
			if (correspondNode == null) {
				correspondNode = rTree.readNode(correspondNodeID);
			}
			DIS.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * save the SNode into Byte Array format:
	 * <p>
	 * childAttrHashValues, childIDs, correspondNodeID, entaValue, gValue, level
	 * 
	 * @return
	 */
	public byte[] saveToBytes() {
		ByteArrayOutputStream bs = new ByteArrayOutputStream();
		DataOutputStream ds = new DataOutputStream(bs);
		/*data.add(childAttrHashValues.size());
		data.addAll(childAttrHashValues);
		data.add(childGValues.size());
		data.addAll(childGValues);
		data.add(entaValue);
		data.add(gValue);
		data.add(level);
		data.add(correspondNodeID);
		//convert to bytes
		int[] result = new int[data.size()];
		for (int i = 0; i < data.size(); i++) {
			result[i] = data.get(i).intValue();
		}
		return result;*/
		try {
			ds.writeInt(childAttrHashValues.size());
			for(Integer x : childAttrHashValues){
				ds.writeInt(x);
			}
			ds.writeInt(childGValues.size());
			for(Integer x : childGValues){
				ds.writeInt(x);
			}
			ds.writeInt(entaValue);
			ds.writeInt(gValue);
			ds.writeInt(level);
			ds.writeInt(correspondNodeID);
			ds.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bs.toByteArray();
	}

	/**
	 * given a RTree node, this method outputs a correspond security node which
	 * has a similar structure
	 * 
	 * @param rTree
	 * @return
	 */
	public static NSecurityNode buildNSecurityNode(RTree rTree) {
		if (rTree == null) {
			return null;
		}
		NSecurityNode.DIMENSION = rTree.m_dimension;
		Node currentNode = rTree.readNode(rTree.m_rootID);
		NSecurityNode node = new NSecurityNode();
		node.buildSecurityInfo(rTree, currentNode);
		return node;
	}

	/**
	 * build the whole architecture of security sub-tree
	 * 
	 * @param node
	 */
	private void buildSecurityInfo(RTree rTree, Node currentNode) {
		//init attributes
		correspondNode = currentNode;
		correspondNodeID = currentNode.m_identifier;
		System.err.println("Build : " + correspondNodeID);
		//gValueComponents = new double[4 * DIMENSION];
		level = correspondNode.m_level;
		//build the security tree
		int childCount = correspondNode.m_children;
		//compute gValue
		//gValueComponents = SecurityUtility.computeGValueComponents(correspondNode.m_nodeMBR);
		//gValue = SecurityUtility.computeHashValue().hashCode();
		if (level > 0) {
			int[] entas = new int[childCount + 1];
			//compute entaVaule
			//entas[0] = gValue;
			entas[0] = 0;
			//internal node, iteration for children
			for (int i = 0; i < childCount; i++) {
				NSecurityNode node = new NSecurityNode();
				node.buildSecurityInfo(rTree, rTree.readNode(correspondNode.getChildIdentifier(i)));
				//childNodes.add(node);
				entas[i + 1] = node.entaValue;
			}
			entaValue = SecurityUtility.computeHashValue(entas).hashCode();
		} else {
			//leaf node
			int[] entas = new int[3 * childCount + 1];
			//compute entaVaule
			//entas[0] = gValue;
			entas[0] = 0;
			//leaf node, iteration for children
			for (int i = 0; i < childCount; i++) {
				//BigInteger[] tmpComponent = SecurityUtility.computeGValueComponents(correspondNode.m_pMBR[i]);
				//childGValueComponents.add(tmpComponent);
				childGValues.add(new Integer(0));
				childAttrHashValues.add(SecurityUtility.computeHashValue(correspondNode.m_pData[i]).hashCode());
				Point p = new Point((int)correspondNode.m_nodeMBR.getLow(0), (int)correspondNode.m_nodeMBR.getLow(1));
				p.buildByPaillier();
				entas[i + 1] = 0;
				entas[2 * i + 1] = SecurityUtility.computeHashValue(correspondNode.m_pData[i]).hashCode();
				//entas[3 * i + 1] = p.HashCode();
			}
			entaValue = SecurityUtility.computeHashValue(entas).hashCode();
		}

		NSecurityTree.saveNSecurityNode(this, currentNode.m_identifier);
	}

	/**
	 * build selves info of security, used in experiment only
	 * 
	 * @param node
	 */
	protected void buildSelfSecurityInfo(RTree rTree, Node currentNode) {
		//init attributes
		correspondNode = currentNode;
		correspondNodeID = currentNode.m_identifier;
		//gValueComponents = new double[4 * DIMENSION];
		level = correspondNode.m_level;
		//build the security tree
		int childCount = correspondNode.m_children;
		//compute gValue
		//gValueComponents = SecurityUtility.computeGValueComponents(correspondNode.m_nodeMBR);
		gValue = SecurityUtility.computeHashValue(SecurityUtility.computeGValueComponents(correspondNode.m_nodeMBR)).hashCode();
		if (level > 0) {
			int[] entas = new int[childCount + 1];
			//compute entaVaule
			entas[0] = gValue;
			//internal node, iteration for children
			for (int i = 0; i < childCount; i++) {
				//childNodes.add(node);
				entas[i + 1] = entaValue;//node.entaValue;
			}
			entaValue = SecurityUtility.computeHashValue(entas).hashCode();
		} else {
			//leaf node
			int[] entas = new int[3 * childCount + 1];
			//compute entaVaule
			entas[0] = gValue;
			//leaf node, iteration for children
			for (int i = 0; i < childCount; i++) {
				BigInteger[] tmpComponent = SecurityUtility.computeGValueComponents(correspondNode.m_pMBR[i]);
				//childGValueComponents.add(tmpComponent);
				childGValues.add(new Integer(SecurityUtility.computeHashValue(tmpComponent).hashCode()));
				childAttrHashValues.add(SecurityUtility.computeHashValue(correspondNode.m_pData[i]).hashCode());
				entas[i + 1] = SecurityUtility.computeHashValue(tmpComponent).hashCode();
				entas[2 * i + 1] = SecurityUtility.computeHashValue(correspondNode.m_pData[i]).hashCode();
				break;//simulate the digest cache
			}
			entaValue = SecurityUtility.computeHashValue(entas).hashCode();
		}
	}

	/**
	 * get the value to prove the relationship
	 * 
	 * @param type
	 *            the relationship between query and node, see IVisitor.TYPE
	 * @return the 4 or 5-*dimension key value of G(), the 5th array is
	 *         complement of NaN when outside
	 */
	public BigInteger[] getEssentialGComponents(int type, Region queryRegion) {
		return SecurityUtility.computeEssentialGValueComponents(correspondNode.m_nodeMBR, type, queryRegion);
	}

	public ArrayList<BigInteger[]> getChildEssentialGValueComponents(int[] childTypes, Region queryRegion) {
		ArrayList<BigInteger[]> result = new ArrayList<BigInteger[]>();
		int childCount = correspondNode.m_children;
		for (int i = 0; i < childCount; i++) {
			result.add(SecurityUtility.computeEssentialGValueComponents(correspondNode.m_pMBR[i], childTypes[i], queryRegion));
		}
		return result;
	}

	public ArrayList<Integer> getChildGValues() {
		return childGValues;
	}

	public ArrayList<Integer> getChildHashValues() {
		return childAttrHashValues;
	}

	public int getEntaValue() {
		return entaValue;
	}

	/*public double[] getGComponents() {
		return gValueComponents;
	}*/

	public int getGValue() {
		return gValue;
	}

	protected int getLevel() {
		return level;
	}

	@Override
	public String toString() {
		String tab = "";
		for (int i = 0; i <= SecurityTree.level - level; i++) {
			tab += "\t";
		}
		String ret = "";
		ret += "SNode[lv:" + level + "\tid:" + correspondNode.m_identifier + "\tet:" + entaValue + "\tg:" + gValue + "\t" + "mbr:" + correspondNode.m_nodeMBR
				+ "\t]";
		/*for (int i = 0; i < childNodes.size(); i++) {
			ret += "\n" + tab + childNodes.get(i).toString();
		}*/
		return ret;
	}

}
