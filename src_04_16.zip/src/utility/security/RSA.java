/**
 * 
 */
package utility.security;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.SecureRandom;


/**
 * @author qchen
 *
 */
public class RSA {

	public static String RSA_ALGORITHM =  "RSA"; 
	public static int DEFAULT_KEYSIZE = 1024;
	public final static BigInteger TWO = new BigInteger("2");
	public static BigInteger PRIME_P = TWO.pow(107).subtract(BigInteger.ONE);
	public BigInteger n, e, d;
	public static boolean isLoad = true;
	public static boolean DEBUG = false;
	public RSA(){
		initKey();
	}
	
	public RSA(int keySize){
		initKey(keySize);
	}
	
	public void initKey(){
		initKey(DEFAULT_KEYSIZE);
	}
	
	/*
	 * initialize public_key and private_key, if isLoad is true, the keys are fixed for experiments
	 * 
	 * @param keySize 
	 * */
	public void initKey(int keySize){
		if(isLoad){
			n = new BigInteger("131884943464045003582223572764312780891162693721585194592930524324036800924838681762453491291771217265809865991455743941676406325061202522717805990960640954746194204966663488362888261025109842355102675226877485643946372964765916251796647608347313211787097206099009857242384502137752539619309766105281035929537");
			e = new BigInteger("162259276829213363391578010288127");
			d = new BigInteger("83449415258234725851576926589709492036325417822780187671214268219104557317967121765323271466150154985252796121180460609454398453624143877649330539413762235154006540684170816796948035994114344229672746485878680815922649054243988474628827807343372872130363224420020644927099041494725797963189924214734565337323");
			DataInputStream dis = null;
			if(DEBUG){
				try {
					dis = new DataInputStream(new FileInputStream("RSA.seeds"));
				} catch (FileNotFoundException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				//dis = new DataInputStream(Thread.currentThread().getContextClassLoader().getResourceAsStream("/RSA.seeds"));
				int len;
				try {
					len = dis.readInt();
					byte[] data = new byte[len];
					dis.read(data, 0, len);
					n = new BigInteger(data);
					System.out.println("\"" + n + "\"");
					len = dis.readInt();
					data = new byte[len];
					dis.read(data, 0, len);
					e = new BigInteger(data);
					System.out.println("\"" + e + "\"");
					len = dis.readInt();
					data = new byte[len];
					dis.read(data, 0, len);
					d = new BigInteger(data);
					System.out.println("\"" + d + "\"");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			return;
		}
		SecureRandom r = new SecureRandom();
	    BigInteger p = new BigInteger(keySize / 2, 100, r);
	    BigInteger q = new BigInteger(keySize / 2, 100, r);
	    n = p.multiply(q);
	    BigInteger m = (p.subtract(BigInteger.ONE))
	                   .multiply(q.subtract(BigInteger.ONE));
	    e =	RSA.PRIME_P;
	    while(m.gcd(e).intValue() > 1) e = e.add(new BigInteger("2"));
	    d = e.modInverse(m);
	    try {
			DataOutputStream dos = new DataOutputStream(new FileOutputStream("RSA.seeds"));
			byte[] data = n.toByteArray();
			try {
				dos.writeInt(data.length);
				dos.write(data);
				data = e.toByteArray();
				dos.writeInt(data.length);
				dos.write(data);
				data = d.toByteArray();
				dos.writeInt(data.length);
				dos.write(data);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public BigInteger encrypt(BigInteger message){
		return message.modPow(e, n);
	}
	
	public BigInteger decrypt(BigInteger message){
		return message.modPow(d, n);
	}
	
	public BigInteger getCondensedRSA(BigInteger[] messages){
		BigInteger ans = BigInteger.ONE;
		for(BigInteger m : messages){
			ans.multiply(m).mod(n);
		}
		return ans;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long start = System.currentTimeMillis();
		RSA condensedRSA = new RSA(1024);
		start = System.currentTimeMillis();
		BigInteger mes = condensedRSA.encrypt(new BigInteger("123"));
		for(int i = 0 ; i < 1; i++){
			//System.out.println(condensedRSA.encrypt(mes));
			condensedRSA.decrypt(mes);
		}
		System.out.println("Time consume : " + (System.currentTimeMillis() - start));
	}

}
