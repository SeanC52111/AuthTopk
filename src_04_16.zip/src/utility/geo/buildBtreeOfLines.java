package utility.geo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Set;

import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;
import utility.Compare.DataOfPoint;
import utility.Compare.buildBtreeOfPoints;

/*
 * remember first build buildBtreeOfPoints to get delaynay information
 * @author qchen
 * */
public class buildBtreeOfLines {
	public static boolean DEBUG = true;
	public static String filename = "database/LinesData.NE.1HOP";
	public RecordManager recmanOfLine;
	public PrimaryTreeMap<Long, byte[]> btOfLine;
	
	public void loadData(int k) throws IOException{
		RecordManager recmanOfPoints = RecordManagerFactory.createRecordManager(buildBtreeOfPoints.filename);
		PrimaryTreeMap<Long, byte[]> btOfPoints = recmanOfPoints.treeMap("treemap");
		Set<Long> keys = btOfPoints.keySet();
		Queue<Long> qLongs = new LinkedList<Long>();
		int timeToCommit = 0, constk = k;
		for(Long key : keys){
			
		//for(Long key = (long) 4000; key <= 5000; key ++){
			//if(key < 8500)continue;
			//if(key == 81158){
				//continue;
				//recmanOfLine.commit();
				//System.out.println(key);
			//}
			k = constk;
			DataOfPoint dataOfPoint = new DataOfPoint();
			byte[] byteData = btOfPoints.find(key);
			dataOfPoint.loadFromBytes(byteData);
			HashSet<Long> cnt = new HashSet<Long>();
			cnt.add(key);
			for(Long id : dataOfPoint.delaunayIds){
				qLongs.offer(id);
				cnt.add(id);
				k ++;
			}
			ArrayList<Long> ids = new ArrayList<Long>();
			ArrayList<Line> lines = new ArrayList<Line>();
			while(!qLongs.isEmpty() && k > 0 && constk >= 0){
				Long id = qLongs.poll();
				byteData = btOfPoints.find(id);
				DataOfPoint tmpDataOfPoint = new DataOfPoint();
				tmpDataOfPoint.loadFromBytes(byteData);
				ids.add(id);
				lines.add(new Line(dataOfPoint.p.doublePoint(), tmpDataOfPoint.p.doublePoint()));
				for(Long tmpLong : tmpDataOfPoint.delaunayIds){
					if(cnt.contains(tmpLong) || qLongs.size() >= k)continue;
					qLongs.offer(tmpLong);
					cnt.add(tmpLong);
				}
				k --;
			}
			DataOfLine newDataOfLine = new DataOfLine(ids.toArray(new Long[0]), lines.toArray(new Line[0]));
			//byte[] testdata = newDataOfLine.writeToBytes();
			btOfLine.put(key, newDataOfLine.writeToBytes());
			timeToCommit ++;
			if(timeToCommit % 500 == 0){
				recmanOfLine.commit();
			}
			if(DEBUG){
				//recmanOfLine.commit();
				System.out.println(key + " has finished");
			}
			qLongs.clear();
		}
		recmanOfLine.commit();
	}
	
	public buildBtreeOfLines(boolean isLoad) throws IOException{
		recmanOfLine = RecordManagerFactory.createRecordManager(filename);
		btOfLine = recmanOfLine.treeMap("treemap");
		//check();
		if(isLoad){
			System.out.println("Input number of k : ");
			Scanner in = new Scanner(System.in);
			int k = in.nextInt();
			loadData(k);
		}
	}
	
	public void check() throws IOException{
		RecordManager recmanOfPoints = RecordManagerFactory.createRecordManager(buildBtreeOfPoints.filename);
		PrimaryTreeMap<Long, byte[]> btOfPoints = recmanOfPoints.treeMap("treemap");
		Set<Long> keys = btOfPoints.keySet();
		for(Long key : keys){
			if(btOfLine.containsKey(key) == false){
				System.err.println("err : id is " + key);
			}
		}
	}
	
	public static void main(String[] args) throws IOException{
		long start = System.currentTimeMillis();
		//filename += args[0];
		buildBtreeOfLines bTree = new buildBtreeOfLines(false); 
		System.out.println("Time consume: " + (System.currentTimeMillis() - start));
		Scanner in = new Scanner(System.in);
		while(true){
			System.out.println("input id below:");
			long id = in.nextLong();
			if(bTree.btOfLine.containsKey(id)){
				System.out.println("Yes! Find it!");
			}
			byte[] str = bTree.btOfLine.find(id);
			DataOfLine dataOfLine = new DataOfLine(str);
			System.out.println(id + " : ");
			for(Long idx : dataOfLine.ids){
				System.out.print(idx + " ");
			}
			System.out.println("");
		}
	}
}
