package utility.security;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Random;

import spatialindex.rtree.NSecurityTree;

public class SeedsGenerater {
	public static BigInteger[] seeds, g_seeds;
	public static Paillier paillier = NSecurityTree.pailliar;
	final static BigInteger ONE = BigInteger.ONE;
	final static BigInteger TWO = BigInteger.ONE.add(BigInteger.ONE);
	public String filename = "seeds";
	public SeedsGenerater(){}
	public SeedsGenerater(int bitlength){
		ArrayList<BigInteger> seedsAL = new ArrayList<BigInteger>(), 
			g_seedsAL = new ArrayList<BigInteger>();
		BigInteger pre =BigInteger.ZERO, cur = ONE;
		seedsAL.add(pre);
		g_seedsAL.add(paillier.Encryption(pre));
		seedsAL.add(cur);
		g_seedsAL.add(paillier.Encryption(cur));
		while(cur.bitLength() < bitlength){
			pre = cur;
			//cur = pre.add(new BigInteger(pre.bitLength() - 1, new Random())).add(ONE);
			cur = pre.multiply(TWO);
			seedsAL.add(cur);
			g_seedsAL.add(paillier.Encryption(cur));
			//System.out.println(cur);
		}
		seeds = (BigInteger [])seedsAL.toArray(new BigInteger[0]);
		g_seeds = (BigInteger[]) g_seedsAL.toArray(new BigInteger[0]);
		try {
			DataOutputStream seedsdos = new DataOutputStream(new FileOutputStream(filename + ".dat"));
			DataOutputStream gseedsdos = new DataOutputStream(new FileOutputStream(filename + ".gdat"));
			try {
				seedsdos.writeInt(seeds.length);
				gseedsdos.writeInt(seeds.length);
				for(BigInteger x : seeds){
					byte[] tmp = x.toByteArray();
					seedsdos.writeInt(tmp.length);
					seedsdos.write(tmp);
				}
				for(BigInteger x : g_seeds){
					byte[] tmp = x.toByteArray();
					gseedsdos.writeInt(tmp.length);
					gseedsdos.write(tmp);
				}
				seedsdos.flush();
				seedsdos.close();
				gseedsdos.flush();
				gseedsdos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public SeedsGenerater(boolean load){
		if(load == false){
			//SeedsGenerater
			return;
		}
		try {
			DataInputStream seedsdis = new DataInputStream(new FileInputStream(filename + ".dat"));
			DataInputStream gseedsdis = new DataInputStream(new FileInputStream(filename + ".gdat"));
			try {
				int len = seedsdis.readInt();
				gseedsdis.readInt();
				seeds = new BigInteger[len];
				g_seeds = new BigInteger[len];
				for(int i = 0 ; i < len; i++){
					int tl = seedsdis.readInt();
					byte[] tmp = new byte[tl];
					seedsdis.read(tmp, 0, tl);
					seeds[i] = new BigInteger(tmp);
					tl = gseedsdis.readInt();
					tmp = new byte[tl];
					gseedsdis.read(tmp, 0, tl);
					g_seeds[i] = new BigInteger(tmp);
				}
				seedsdis.close();
				gseedsdis.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public BigInteger[] Decompose(BigInteger val){
		ArrayList<BigInteger> factors = new ArrayList<BigInteger>();
		BigInteger zeroOfPaillliar = paillier.Encryption(BigInteger.ZERO);
		for(int i = seeds.length - 1 ; i >= 0; i --){
			if(val.compareTo(seeds[i]) >= 0){
				val = val.subtract(seeds[i]);
				factors.add(g_seeds[i]);
			}else{
				factors.add(zeroOfPaillliar);
			}
		}
		return (BigInteger[])factors.toArray(new BigInteger[0]);
	}
	
	public static void main(String args[]){
		//SeedsGenerater seed = new SeedsGenerater(256);
		SeedsGenerater seed = new SeedsGenerater(true);
		System.out.println("seeds' size : " + seed.seeds.length);
		for(BigInteger x : seed.seeds){
			System.out.println(x);
		}
	}
}
