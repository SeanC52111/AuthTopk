/**
 * 
 */
package spatialindex.rtree;

import spatialindex.core.IEntry;
import spatialindex.core.IQueryStrategy;

/**
 * @author qchen
 *
 */
public class BuildRTreeStrategy implements IQueryStrategy {

	/* (non-Javadoc)
	 * @see spatialindex.core.IQueryStrategy#getNextEntry(spatialindex.core.IEntry, int[], boolean[])
	 */

	
	@Override
	public void getNextEntry(IEntry arg0, int[] arg1, boolean[] arg2) {
		// TODO Auto-generated method stub
		Node node = (Node)arg0;
		for(int i = 0 ; i < node.m_children; i ++){
			
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
