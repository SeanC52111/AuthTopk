/**
 * 
 */
package utility;

import java.io.PrintWriter;

/**
 * @author chenqian
 *
 */
public class StatisticForAuth {

	public long pre_time_SP;//ms
	public long con_time_SP;//ms
	public long vrf_time_CL;//ms
	public long size_VO;//byte
	public long num_PPB;
	public long num_PLB;
	public long num_Gf;
	
	public void reset(){
		con_time_SP = 0;
		vrf_time_CL = 0;
		size_VO = 0;
		num_PPB = 0;
		num_PLB = 0;
		num_Gf = 0;
	}
	
	public StatisticForAuth(){
		reset();
	}
	
	public void print(){
		System.out.println("===============================================");
		System.out.println("Preparation time for server: " + pre_time_SP + " ms");
		System.out.println("Construction time for server: " + con_time_SP + " ms");
		System.out.println("Verification time for clients: " + vrf_time_CL + " ms");
		System.out.println("Size of VO: " + size_VO + " byte = " + (size_VO / 1024) + " KB");
		System.out.println("Number of PPB function calls: " + num_PPB);
		System.out.println("Number of PLB function calls: " + num_PLB);
		System.out.println("Number of G function calls: " + num_Gf);
	}
	
	public void printtoffile(PrintWriter pw){
		pw.println(pre_time_SP);
		pw.println(con_time_SP);
		pw.println(vrf_time_CL);
		pw.println(size_VO);
		pw.println(num_PPB);
		pw.println(num_PLB);
		pw.println(num_Gf);
		pw.println("");
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
