package spatialindex.rtree;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;

import spatialindex.core.IShape;
import spatialindex.core.Region;
import utility.SecurityUtility;
import utility.Statistics;
import utility.Compare.DataOfPoint;
import utility.Compare.DistanceCompare;
import utility.Compare.buildBtreeOfPoints;
import utility.geo.DataOfLine;
import utility.geo.Line;
import utility.geo.buildBtreeOfLines;
import utility.security.IVo;
import utility.security.Point;
import utility.security.RSA;

public class VO implements IVo{
	public Statistics statistics = new Statistics();
	public boolean DEBUG = false;
	public boolean MIN_SAPN_TREE = false;
	public int[] p_id, p_x, p_y;
	public int kNum;
	public ArrayList<IVo> nearVos = new ArrayList<IVo>(), farVos = new ArrayList<IVo>(), gfVos = new ArrayList<IVo>();
	RecordManager recordOfPoint = null;
	RecordManager recordOfLine = null;
	public RSA rsa;
	public BigInteger RSAValueByServer;
	public VO(){}
	public VO(Integer[] ids, IShape[] shapes, int kNum, int q_x, int q_y, boolean IS_MIN_SPAN_TREE){
		rsa = new RSA(1024);
		long start = System.currentTimeMillis();
		statistics.k_of_knn = kNum;
		statistics.kind = false;
		this.kNum = kNum;
		MIN_SAPN_TREE = IS_MIN_SPAN_TREE;
		p_id = new int[ids.length];
		p_x = new int[ids.length];
		p_y = new int[ids.length];
		for(int i = 0; i < shapes.length; i++){
			Region p = (Region)shapes[i];
			if(i < kNum || ids[i] > 0){
				p_id[i] = ids[i];
				p_x[i] = (int)p.getLow(0);
				p_y[i] = (int)p.getLow(1);
			}else{
				p_id[i] = -1 - i;
				int a = 1, b = 1, p1 = (int)p.getLow(0), p2 = (int)p.getLow(1), q1 = (int)p.getHigh(0), q2 = (int)p.getHigh(1);
				if(q_x < p1){
					a = 0;
				}else if(q_x > q1){
					a = 2;
				}
				if(q_y < p2){
					b = 0;
				}else if(q_y > q2){
					b = 2;
				}
				if(a == 0){
					if(b == 0){
						p_x[i] = (int)p.getLow(0);
						p_y[i] = (int)p.getLow(1);
					}else if(b == 1){
						p_x[i] = (int)p.getLow(0);
						p_y[i] = q_y;
					}else{
						p_x[i] = (int)p.getLow(0);
						p_y[i] = (int)p.getHigh(1);
					}
				}else if(a == 1){
					if(b == 0){
						p_x[i] = q_x;
						p_y[i] = (int)p.getLow(1);
					}else if(b == 2){
						p_x[i] = q_x;
						p_y[i] = (int)p.getHigh(1);
					}
				}else {
					if(b == 0){
						p_x[i] = (int)p.getHigh(0);
						p_y[i] = (int)p.getLow(1);
					}else if(b == 1){
						p_x[i] = (int)p.getLow(0);
						p_y[i] = q_y;
					}else{
						p_x[i] = (int)p.getHigh(0);
						p_y[i] = (int)p.getHigh(1);
					}
				}
				ODGfunction odGfunction = new ODGfunction(a, b, p_x[i], p_y[i]);
				odGfunction.GenerateVeryfyPart(q_x, q_y);
				gfVos.add(odGfunction);
			}
		}
		build(q_x, q_y);
		statistics.construction_time += System.currentTimeMillis() - start;
	}
	
	private void load_btree(){
		try {
			recordOfPoint = RecordManagerFactory.createRecordManager(buildBtreeOfPoints.filename);
			recordOfLine = RecordManagerFactory.createRecordManager(buildBtreeOfLines.filename);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void build(int q_x, int q_y){
		long loadingStart;
		try{
			load_btree();
			final PrimaryTreeMap<Long, byte[]> btOfPoint = recordOfPoint.treeMap("treemap");
			PrimaryTreeMap<Long, byte[]> btOfLine = recordOfLine.treeMap("treemap");
			if(MIN_SAPN_TREE){
				//load
				long k_id = p_id[kNum - 1], cur_id = kNum - 1;
				DataOfPoint dataOfPoint_k_id = new DataOfPoint();
				loadingStart = System.currentTimeMillis();
				dataOfPoint_k_id.loadFromBytes(btOfPoint.find(k_id));
				statistics.load_time += System.currentTimeMillis() - loadingStart;
				HashMap<Long, Long> idmap = new HashMap<Long, Long>();
				//initial
				//for far
				ArrayList<Long> farids = new ArrayList<Long>();
				
				//for near
				final Point qPoint = new Point(q_x, q_y);
				
				int[] weight = new int[kNum], cnt = new int[kNum];
				for(int i = 0; i < kNum; i++){
					weight[i] = -1;
					cnt[i] = 0;
					idmap.put((long)p_id[i], (long)i);
				}
				cnt[kNum - 1] = 1;
				Line[] lines = new Line[kNum];
				
				for(int i = 0 ; i < kNum - 1; i++){
					boolean found = false;
					loadingStart = System.currentTimeMillis();
					DataOfLine dataOfLine = new DataOfLine(btOfLine.find((long) p_id[(int) cur_id]));
					statistics.load_time += System.currentTimeMillis() - loadingStart;
					for(int  j = 0; j < dataOfLine.lines.length; j++){
						long t_id = dataOfLine.ids[j];
						if(idmap.containsKey(t_id)){
							int tt = idmap.get(t_id).intValue();
							if(weight[tt] != -1 || cnt[tt] != 0)continue;
							weight[tt] = (int) cur_id;
							lines[tt] = dataOfLine.lines[j];
							long genStart = System.currentTimeMillis();
							lines[tt].GenerateVeryfyPart(qPoint);
							statistics.generate_time += System.currentTimeMillis() - genStart;
						}
					}
					for(int j = 0; j < kNum; j++){
						if(cnt[j] == 0)cur_id = j;
						if(cnt[j] == 0 && weight[j] != -1){
							found = true;
							nearVos.add(lines[j]);
							statistics.num_of_Lines ++;
							break;
						}
					}
					if(!found){
						DataOfPoint dataOfPoint_t_id = new DataOfPoint();
						loadingStart = System.currentTimeMillis();
						dataOfPoint_t_id.loadFromBytes(btOfPoint.find((long) p_id[(int) cur_id]));
						statistics.load_time += System.currentTimeMillis() - loadingStart;
						DistanceCompare distanceCompare = new DistanceCompare(dataOfPoint_t_id.p, dataOfPoint_k_id.p, true);
						long genStart = System.currentTimeMillis();
						distanceCompare.GenerateVeryfyPart(qPoint);
						statistics.generate_time += System.currentTimeMillis() - genStart;
						nearVos.add(distanceCompare);
						statistics.num_of_Pailliar ++;
					}
					cnt[(int) cur_id] = 1;
				}
				
				for(int i = kNum; i < p_id.length; i++){
					farids.add((long)p_id[i]);
				}
				farids.add(k_id);
				idmap.clear();
				weight = new int[farids.size()];
				cnt = new int[farids.size()];
				for(int i = 0; i < farids.size(); i++){
					weight[i] = -1;
					cnt[i] = 0;
					idmap.put((long)farids.get(i), (long)i);
				}
				cnt[farids.size() - 1] = 1;
				lines = new Line[farids.size()];
				cur_id = farids.size() - 1;
				
				for(int i = 0 ; i < farids.size() - 1; i++){
					boolean found = false;
					if(farids.get((int)cur_id) > 0){
						loadingStart = System.currentTimeMillis();
						DataOfLine dataOfLine = new DataOfLine(btOfLine.find(farids.get((int) cur_id)));
						statistics.load_time += System.currentTimeMillis() - loadingStart;
						for(int  j = 0; j < dataOfLine.lines.length; j++){
							long t_id = dataOfLine.ids[j];
							if(idmap.containsKey(t_id)){
								int tt = idmap.get(t_id).intValue();
								if(weight[tt] != -1 || cnt[tt] != 0)continue;
								weight[tt] = (int) cur_id;
								lines[tt] = dataOfLine.lines[j];
								long genStart = System.currentTimeMillis();
								lines[tt].GenerateVeryfyPart(qPoint);
								statistics.generate_time += System.currentTimeMillis() - genStart;
							}
						}
					}
					for(int j = 0; j < farids.size(); j++){
						if(cnt[j] == 0)cur_id = j;
						if(cnt[j] == 0 && weight[j] != -1){
							found = true;
							farVos.add(lines[j]);
							statistics.num_of_Lines ++;
							break;
						}
					}
					if(!found){
						DataOfPoint dataOfPoint_t_id = new DataOfPoint();
						Point t_id_point;
						loadingStart = System.currentTimeMillis();
						if(farids.get((int) cur_id) < 0){
							int id_in_arrays = (int) -(farids.get((int) cur_id) + 1);
							t_id_point = new Point(p_x[id_in_arrays], p_y[id_in_arrays]);
							t_id_point.buildByPaillier();
						}else{
							dataOfPoint_t_id.loadFromBytes(btOfPoint.find(farids.get((int) cur_id)));
							t_id_point = new Point(dataOfPoint_t_id.p, true);
						}
						statistics.load_time += System.currentTimeMillis() - loadingStart;
						DistanceCompare distanceCompare = new DistanceCompare(dataOfPoint_k_id.p, t_id_point, true);
						long genStart = System.currentTimeMillis();
						distanceCompare.GenerateVeryfyPart(qPoint);
						statistics.generate_time += System.currentTimeMillis() - genStart;
						farVos.add(distanceCompare);
						statistics.num_of_Pailliar ++;
					}
					cnt[(int) cur_id] = 1;
				}
			}
			else{

				long k_id = p_id[kNum - 1], cur_id = kNum - 1;
				DataOfPoint dataOfPoint_k_id = new DataOfPoint();
				dataOfPoint_k_id.loadFromBytes(btOfPoint.find(k_id));
				HashMap<Long, Long> idmap = new HashMap<Long, Long>();
				DataOfLine dataOfLine_k_id = new DataOfLine(btOfLine.find(k_id));
				//initial
				//for far
				ArrayList<Long> farids = new ArrayList<Long>();
				
				//for near
				final Point qPoint = new Point(q_x, q_y);
				
				int[] weight = new int[kNum];
				for(int i = 0; i < kNum; i++){
					weight[i] = -1;
					idmap.put((long)p_id[i], (long)i);
				}
				Line[] lines = new Line[kNum];
				for(int  j = 0; j < dataOfLine_k_id.lines.length; j++){
					long t_id = dataOfLine_k_id.ids[j];
					if(idmap.containsKey(t_id)){
						int tt = idmap.get(t_id).intValue();
						if(weight[tt] != -1)continue;
						weight[tt] = (int) cur_id;
						lines[tt] = dataOfLine_k_id.lines[j];
						long genStart = System.currentTimeMillis();
						lines[tt].GenerateVeryfyPart(qPoint);
						statistics.generate_time += System.currentTimeMillis() - genStart;
					}
				}
				for(int i = 0 ; i < kNum - 1; i++){
					if(weight[i] != -1){
						nearVos.add(lines[i]);
						statistics.num_of_Lines ++;
					}else{
						DataOfPoint dataOfPoint_t_id = new DataOfPoint();
						dataOfPoint_t_id.loadFromBytes(btOfPoint.find((long) p_id[(int) cur_id]));
						DistanceCompare distanceCompare = new DistanceCompare(dataOfPoint_t_id.p, dataOfPoint_k_id.p, true);
						long genStart = System.currentTimeMillis();
						distanceCompare.GenerateVeryfyPart(qPoint);
						statistics.generate_time += System.currentTimeMillis() - genStart;
						nearVos.add(distanceCompare);
						statistics.num_of_Pailliar ++;
					}
				}

				for(int i = kNum; i < p_id.length; i++){
					farids.add((long) p_id[i]);
				}
				
				farids.add(k_id);
				idmap.clear();
				weight = new int[farids.size()];
				for(int i = 0; i < farids.size(); i++){
					weight[i] = -1;
					idmap.put((long)farids.get(i), (long)i);
				}
				lines = new Line[farids.size()];
				cur_id = farids.size() - 1;
				for(int  j = 0; j < dataOfLine_k_id.lines.length; j++){
					long t_id = dataOfLine_k_id.ids[j];
					if(idmap.containsKey(t_id)){
						int tt = idmap.get(t_id).intValue();
						if(weight[tt] != -1)continue;
						weight[tt] = (int) cur_id;
						lines[tt] = dataOfLine_k_id.lines[j];
						long genStart = System.currentTimeMillis();
						lines[tt].GenerateVeryfyPart(qPoint);
						statistics.generate_time += System.currentTimeMillis() - genStart;
					}
				}
				for(int i = 0 ; i < farids.size() - 1; i++){
					if(weight[i] != -1){
						farVos.add(lines[i]);
						statistics.num_of_Lines ++;
					}
					else{
						DataOfPoint dataOfPoint_t_id = new DataOfPoint();
						Point t_id_point;
						loadingStart = System.currentTimeMillis();
						if(farids.get((int) cur_id) < 0){
							int id_in_arrays = (int) -(cur_id + 1);
							t_id_point = new Point(p_x[id_in_arrays], p_y[id_in_arrays]);
							t_id_point.buildByPaillier();
						}else{
							dataOfPoint_t_id.loadFromBytes(btOfPoint.find(farids.get((int) cur_id)));
							t_id_point = new Point(dataOfPoint_t_id.p, true);
						}
						statistics.load_time += System.currentTimeMillis() - loadingStart;
						DistanceCompare distanceCompare = new DistanceCompare(dataOfPoint_k_id.p, t_id_point, true);
						long genStart = System.currentTimeMillis();
						distanceCompare.GenerateVeryfyPart(qPoint);
						statistics.generate_time += System.currentTimeMillis() - genStart;
						farVos.add(distanceCompare);
						statistics.num_of_Pailliar ++;
					}
				}
			}
			recordOfPoint.close();
			recordOfLine.close();
			buildRSA();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void buildRSA(){
		
		ArrayList<BigInteger> hashfactors = new ArrayList<BigInteger>();
		for(int i = 0; i < nearVos.size(); i++){
			hashfactors.add(new BigInteger(nearVos.get(i).getHashcode(), 16));
		}
		for(int i = 0; i < farVos.size(); i++){
			hashfactors.add(new BigInteger(farVos.get(i).getHashcode(), 16));
		}
		for(int i = 0 ; i < gfVos.size(); i++){
			hashfactors.add(new BigInteger(gfVos.get(i).getHashcode(), 16));
		}
		
		long start = System.currentTimeMillis();
		String hashvalue = SecurityUtility.computeHashValue(hashfactors.toArray(new BigInteger[0]));
		RSAValueByServer = rsa.encrypt(new BigInteger(hashvalue, 16));
		statistics.generate_time += System.currentTimeMillis() - start;
	}
	@Override
	public boolean ClientVerify(int q_x, int q_y) {
		// TODO Auto-generated method stub
		long start = System.currentTimeMillis();
		ArrayList<BigInteger> hashfactors = new ArrayList<BigInteger>();
		for(int i = 0; i < nearVos.size(); i++){
			hashfactors.add(new BigInteger(nearVos.get(i).getHashcode(), 16));
			if(nearVos.get(i).ClientVerify(q_x, q_y) == false){
				System.err.println("near vor :" + i);
				return false;
			}
		}
		for(int i = 0; i < farVos.size(); i++){
			if(DEBUG)System.out.println(i);
			hashfactors.add(new BigInteger(farVos.get(i).getHashcode(), 16));
			if(farVos.get(i).ClientVerify(q_x, q_y) == false){
				System.err.println("far vor : " + i);
				return false;
			}
		}
		for(int i = 0 ; i < gfVos.size(); i++){
			hashfactors.add(new BigInteger(gfVos.get(i).getHashcode(), 16));
			if(gfVos.get(i).ClientVerify(q_x, q_y) == false){
				System.err.println("gf vor : " + i);
				return false;
			}
		}
		String hashvalue = SecurityUtility.computeHashValue(hashfactors.toArray(new BigInteger[0]));
		BigInteger RSAValueByClient = rsa.encrypt(new BigInteger(hashvalue, 16));
		if(RSAValueByServer.equals(RSAValueByClient) == false)return false;
		statistics.num_of_near_points = nearVos.size();
		statistics.num_of_far_points = farVos.size();
		statistics.num_of_gf_points = gfVos.size();
		statistics.verify_time += System.currentTimeMillis() - start;
		return true;	
	}
	/* (non-Javadoc)
	 * @see utility.security.IVo#getHashcode()
	 */
	@Override
	public String getHashcode() {
		// TODO Auto-generated method stub
		return null;
	}
}
