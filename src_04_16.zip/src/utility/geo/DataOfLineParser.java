/**
 * 
 */
package utility.geo;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;
import java.util.StringTokenizer;

import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;

import utility.Compare.DataOfPoint;
import utility.security.Point;

/**
 * @author qchen
 *
 */
public class DataOfLineParser {

	public static String filein = "./tmp/output";
	public static String filename = "./database/LinesData.NE.1HOP";
	public RecordManager recmanOfLine;
	public PrimaryTreeMap<Long, byte[]> btOfLine;
	/**
	 * @param args
	 */
	
	public void loadData(){
		long start, t1;
		try {
			File files = new File(filein);
			if(!files.exists()){
				throw new FileNotFoundException();
			}
			if(files.isDirectory()){
				File[] file = files.listFiles();
				for(int i = 0 ; i < file.length; i++){
					System.out.println(file[i].toString());
					DataInputStream dis = new DataInputStream(new BufferedInputStream(new FileInputStream(file[i])));
					try {
						int lines = 0;
						long all = 0, all1 = 0;
						t1 = System.currentTimeMillis();
						while(dis.available() != 0){
							lines ++;
							dis.skipBytes(1);
							int id = dis.readInt();
							start = System.currentTimeMillis();
							dis.mark(1 << 20);
							int len = DataOfLine.seekLen(dis);
							byte[] data = new byte[len];
							dis.reset();
							dis.readFully(data);
							all1 += System.currentTimeMillis() - start;
							dis.skipBytes(1);
							btOfLine.put((long) id, data);
							if(lines % 50 == 0){
								System.out.print(".");
								if(lines % 1000 == 0)System.out.println();
								start = System.currentTimeMillis();
								recmanOfLine.commit();
								all += System.currentTimeMillis() - start;
							}
						}
						recmanOfLine.commit();
						System.out.println(all + " " + all1 + " " + (System.currentTimeMillis() - t1));
						dis.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public DataOfLineParser(boolean needLoad) throws IOException{
		System.out.println("Please input the filein:");
		Scanner in = new Scanner(System.in);
		filein = in.nextLine();
		System.out.println("Please input the filename:");
		filename = in.nextLine();
		System.out.println("Load or not(yes or no):");
		String isLoad = in.nextLine();
		recmanOfLine = RecordManagerFactory.createRecordManager(filename);
		btOfLine = recmanOfLine.treeMap("treemap");
		if(isLoad.equals("yes")){
			loadData();
		}
	}
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		long start = System.currentTimeMillis();
		//filename += args[0];
		DataOfLineParser bTree = new DataOfLineParser(true); 
		System.out.println("Time consume: " + (System.currentTimeMillis() - start));
		Scanner in = new Scanner(System.in);
		while(true){
			System.out.println("input id below:");
			long id = in.nextLong();
			if(bTree.btOfLine.containsKey(id)){
				System.out.println("Yes! Find it!");
			}
			byte[] str = bTree.btOfLine.find(id);
			DataOfLine dataOfLine = new DataOfLine(str);
			System.out.println(id + " : ");
			for(Long idx : dataOfLine.ids){
				System.out.print(idx + " ");
			}
			System.out.println("");
		}
	}
}
