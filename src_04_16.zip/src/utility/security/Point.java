package utility.security;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.math.BigInteger;

import spatialindex.rtree.NSecurityTree;
import utility.SecurityUtility;
import utility.math.BigIntegerUtility;

public class Point {
	public long x, y;
	public BigInteger g_a2p_x2, g_a2p_y2, g_2a2p_x, g_2a2p_y;
	public BigInteger g_a2;
	public BigInteger g_a2_q_x, g_a2_q_y;
	public static SeedsGenerater seeds = NSecurityTree.seeds;
	public static Paillier pailliar = NSecurityTree.pailliar;
	public static BigInteger a2 = NSecurityTree.a.multiply(NSecurityTree.a);
	
	public Point(){
		x = 0; 
		y = 0;
	}
	public Point(long _x, long _y){
		x = _x;
		y = _y;
	}
	public Point(long[] c){
		x = c[0];
		y = c[1];
	}
	
	public Point(int[] c){
		x = c[0];
		y = c[1];
	}
	
	public Point(Point _p){
		this.x = _p.x;
		this.y = _p.y;
	}
	
	public Point(Point _p, boolean isLoad){
		this.x = _p.x;
		this.y = _p.y;
		if(isLoad){
			this.g_2a2p_x = _p.g_2a2p_x;
			this.g_2a2p_y = _p.g_2a2p_y;
			this.g_a2 = _p.g_a2;
			this.g_a2p_x2 = _p.g_a2p_x2;
			this.g_a2p_y2 = _p.g_a2p_y2;
		}
	}
	
	public Point doublePoint(){
		return new Point(x * 2, y * 2);
	}
	
	public void Add(Point q){
		x += q.x;
		y += q.y;
	}
	
	public static long Areax2(Point L, Point H, Point Q){
		return (Q.x - H.x) * (Q.y - L.y) - (Q.y - H.y) * (Q.x - L.x);
	}
	
	public static long Distance2(Point a, Point b){
		return (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);
	}
	
	private static long Distance2(long x1, long y1, long x2, long y2) {
		// TODO Auto-generated method stub
		return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);
		//return null;
	}
	public static BigInteger[] buildFactorsByPaillier(Point pL, Point pH, long q_x, long q_y){
		BigInteger dis1 = new BigInteger(new Long(Point.Distance2(pH.x, pH.y, q_x, q_y)).toString());
		BigInteger dis2 = new BigInteger(new Long(Point.Distance2(pL.x, pL.y, q_x, q_y)).toString());
//		BigInteger b_q_x = new BigInteger(new Integer((int)q_x).toString()), b_q_y = new BigInteger(new Integer((int)q_y).toString());
//		pL.g_a2_q_x = pL.g_a2.modPow(b_q_x, pailliar.nsquare);
//		pL.g_a2_q_y = pL.g_a2.modPow(b_q_y, pailliar.nsquare);
//		pH.g_a2_q_x = pH.g_a2.modPow(b_q_x, pailliar.nsquare);
//		pH.g_a2_q_y = pH.g_a2.modPow(b_q_y, pailliar.nsquare);
		return seeds.Decompose(dis1.subtract(dis2).multiply(a2));
	}
	
	public BigInteger CompositionPart1(int q_x, int q_y){
		//long start = System.currentTimeMillis();
		BigInteger b_q_x = new BigInteger(new Integer((int)q_x).toString()), b_q_y = new BigInteger(new Integer((int)q_y).toString());
		//start = System.currentTimeMillis();
		BigInteger g_a2_q_x = g_a2.modPow(b_q_x, pailliar.nsquare);
		BigInteger g_a2_q_y = g_a2.modPow(b_q_y, pailliar.nsquare);
		//System.err.println(System.currentTimeMillis() - start);
		BigInteger dis1 = g_a2p_x2.multiply(g_a2_q_x).mod(pailliar.nsquare);
		BigInteger dis2 = g_a2p_y2.multiply(g_a2_q_y).mod(pailliar.nsquare);
		//System.err.println(System.currentTimeMillis() - start);
		return dis1.multiply(dis2).mod(pailliar.nsquare);
	}
	
	public BigInteger CompositionPart2(int q_x, int q_y){
		BigInteger b_q_x = new BigInteger(new Integer(q_x).toString()), b_q_y = new BigInteger(new Integer(q_y).toString());
		BigInteger dis1 = g_2a2p_x.modPow(b_q_x, pailliar.nsquare);
		BigInteger dis2 = g_2a2p_y.modPow(b_q_y, pailliar.nsquare);
		return dis1.multiply(dis2).mod(pailliar.nsquare);
	}
	
	public void buildByPaillier(){
		g_a2 = pailliar.Encryption(a2);
		//factors = seeds.Decompose(paillier.Encryption(Distance2(pH.x, pH.y, q_x, q_y).subtract(Distance2(pL.x, pL.y, q_x, q_y)).multiply(a2)));
		BigInteger b_x = new BigInteger(new Long(x).toString());
		BigInteger b_y = new BigInteger(new Long(y).toString());
		g_a2p_x2 = pailliar.Encryption(b_x.multiply(b_x).multiply(a2));
		//System.err.println("x^2 = " + paillier.Decryption(g_a2p_x2).divide(a2));
		g_a2p_y2 = pailliar.Encryption(b_y.multiply(b_y).multiply(a2));
		g_2a2p_x = pailliar.Encryption(b_x.multiply(a2).multiply(BigIntegerUtility.TWO));
		g_2a2p_y = pailliar.Encryption(b_y.multiply(a2).multiply(BigIntegerUtility.TWO));
	}
	
	public void readFromFile(DataInputStream dis){
		try {
			x = dis.readLong();
			y = dis.readLong();
			int len = dis.readInt();
			byte[] data = new byte[len];
			dis.read(data, 0, len);
			g_a2p_x2 = new BigInteger(data);
			len = dis.readInt();
			data = new byte[len];
			dis.read(data, 0, len);
			g_a2p_y2 = new BigInteger(data);
			len = dis.readInt();
			data = new byte[len];
			dis.read(data, 0, len);
			g_2a2p_x = new BigInteger(data);
			len = dis.readInt();
			data = new byte[len];
			dis.read(data, 0, len);
			g_2a2p_y = new BigInteger(data);
			len = dis.readInt();
			data = new byte[len];
			dis.read(data, 0, len);
			g_a2 = new BigInteger(data);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void writeToFile(DataOutputStream dos){
		try {
			dos.writeLong(x);
			dos.writeLong(y);
			byte[] data = g_a2p_x2.toByteArray();
			dos.writeInt(data.length);
			dos.write(data);
			data = g_a2p_y2.toByteArray();
			dos.writeInt(data.length);
			dos.write(data);
			data = g_2a2p_x.toByteArray();
			dos.writeInt(data.length);
			dos.write(data);
			data = g_2a2p_y.toByteArray();
			dos.writeInt(data.length);
			dos.write(data);
			data = g_a2.toByteArray();
			dos.writeInt(data.length);
			dos.write(data);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String HashCode(){
		BigInteger[] tmp = {g_a2p_x2, g_a2p_y2, g_2a2p_x, g_2a2p_y, g_a2};
		return SecurityUtility.computeHashValue(tmp);
	}
	
	public String compactHashCode(){
		return SecurityUtility.computeHashValue(new BigInteger[]{
			new BigInteger(new Long(x).toString()),
			new BigInteger(new Long(y).toString())
		});
	}
	
	public static void main(String args[]){
		Point L = new Point(1, 0), H = new Point(0, 1), Q = new Point(1, 1);
		System.out.println("areax2 : " + Point.Areax2(L, H, Q));
	}
	
	
}
