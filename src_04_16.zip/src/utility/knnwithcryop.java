package utility;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import spatialindex.core.IData;
import spatialindex.core.INode;
import spatialindex.core.IShape;
import spatialindex.core.IVisitor;
import spatialindex.core.Point;
import spatialindex.core.Region;
import spatialindex.io.DiskStorageManager;
import spatialindex.io.IBuffer;
import spatialindex.io.IStorageManager;
import spatialindex.io.RandomEvictionsBuffer;
import spatialindex.rtree.MyRtree;
import spatialindex.rtree.RTree;
import spatialindex.rtree.NSecurityTree;
import spatialindex.rtree.VO;
import spatialindex.setting.PropertySet;


public class knnwithcryop {
	
	public static RTree rtree;
	public static MyRtree myrtree;
	public static NSecurityTree srtree;
	public static String FileInPath = "input/data.in";
	public static Stat stat1, stat2, stat3, stat4;
	public static boolean IS_BATCH_QUERY;
	public static PrintWriter datapw;
	public static void LoadTree(String localRtreeFilePath) throws SecurityException, NullPointerException, FileNotFoundException, IllegalArgumentException, IOException{
		//load rtree

		PropertySet ps = new PropertySet();
		ps.setProperty("FileName", localRtreeFilePath); // .idx and .dat extensions will be added.
		IStorageManager diskfile = new DiskStorageManager(ps);
		IBuffer file = new RandomEvictionsBuffer(diskfile, 10, false);
		PropertySet ps2 = new PropertySet();
		Integer i = new Integer(1);
		ps2.setProperty("IndexIdentifier", i);
		rtree = new RTree(ps2, file);
		//load SRTree
		//srtree = new NSecurityTree(rtree, localRtreeFilePath);
	}
	
	public static void LoadMyRTree(String localRtreeFilePath) throws SecurityException, NullPointerException, FileNotFoundException, IllegalArgumentException, IOException{
		//load rtree

		PropertySet ps = new PropertySet();
		ps.setProperty("FileName", localRtreeFilePath); // .idx and .dat extensions will be added.
		IStorageManager diskfile = new DiskStorageManager(ps);
		IBuffer file = new RandomEvictionsBuffer(diskfile, 10, false);
		PropertySet ps2 = new PropertySet();
		Integer i = new Integer(1);
		ps2.setProperty("IndexIdentifier", i);
		myrtree = new MyRtree(ps2, file);
		//load SRTree
		//srtree = new NSecurityTree(rtree, localRtreeFilePath);
	}
	
	public static void main(String args[]) throws IOException{
		Scanner in = new Scanner(System.in);
			
		stat1 = new knnwithcryop().new Stat();
		stat2 = new knnwithcryop().new Stat();
		stat3 = new knnwithcryop().new Stat();
		stat4 = new knnwithcryop().new Stat();
		
		//System.out.println("input \"build\" means build a new tree, \"load\" means load from file");
		//String line = in.nextLine();
		while(true){
			System.out.println("(a) genrate data\n(b) build a tree\n(c) load a tree\n(d) knn query\n(e) batch query\n(f) exit.");
			String line = in.nextLine();
			if(line.equals("a")){
				System.out.println("input number range, quantity of number, filepath respectively:");
				String[] val = in.nextLine().split(" ");
				generator.GeneratePointsofInteger(Integer.parseInt(val[0]), Integer.parseInt(val[1]), val[2]);
				System.out.println("Success!");
			}else if(line.equals("b")){
				System.out.println("input name of infile and outfile");
				String[] files = in.nextLine().split(" ");
				rtree = RTree.createRTree(new String[] {files[0], files[1], "100", "10nn" });
				/*srtree = new NSecurityTree(rtree);
				try {
					srtree.writeToFile(files[1]);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
			}else if(line.equals("c")){
				System.out.println("input filename:");
				String filename = in.nextLine();
				try {
					LoadTree(filename);
					LoadMyRTree(filename);
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (NullPointerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Load Successfully!");
			}else if(line.equals("d")){
				IS_BATCH_QUERY = false;
				System.out.println("===========start query===========");
				while(true){
					System.out.println("(a) new query\n(b) exit");
					String val = in.nextLine();
					if(val.equals("b") == true){
						System.out.println("===========end query===========");
						break;
					}
					System.out.println("Please input the k of knn:");
					int kNum = Integer.parseInt(in.nextLine());
					System.out.println("Please input the coordinate of point:");
					String[] coords = in.nextLine().split(" ");
					Point pt = new Point(new double[]{Double.parseDouble(coords[0]), Double.parseDouble(coords[1])});
					query(kNum, pt);
				}
			}else if(line.equals("e")){
				IS_BATCH_QUERY = true;
				System.out.println("Please input query's filename");
				String filename = in.nextLine();
				System.out.println("Please input answer of query's file name");
				String ans_file_name = in.nextLine();
				int[] k_of_knn = {1, 2, 4, 8, 16, 32, 64, 128};
				for(int i = 0; i < 8; i ++){
					datapw = new PrintWriter(new FileOutputStream(new File(ans_file_name + "_" + new Integer(i).toString() + ".data")));
					int lines = 0;
					stat1.reset();stat2.reset();stat3.reset();stat4.reset();
					Scanner in1 = new Scanner(new FileInputStream(new File(filename)));
					while(in1.hasNext()){
						lines ++;
						//if(lines % 50 == 0)
							System.out.println("case : " + lines);
						//else System.out.print(".");
						String[] tokens = in1.nextLine().split(" ");
						Point pt = new Point(new double[]{Double.parseDouble(tokens[0]), Double.parseDouble(tokens[1])});
						query(k_of_knn[i], pt);
						if(lines > 100)break;
					}
					in1.close();
					
					PrintWriter pw = new PrintWriter(new FileOutputStream(new File(ans_file_name + "_" + new Integer(i).toString())));
					stat1.print(lines);
					stat1.printtoffile(lines, pw);
					stat2.print(lines);
					stat2.printtoffile(lines, pw);
					stat3.print(lines);
					stat3.printtoffile(lines, pw);
					stat4.print(lines);
					stat4.printtoffile(lines, pw);
					pw.flush();
					pw.close();
					datapw.flush();
					datapw.close();
				}
			}if(line.equals("f")){
				System.out.println("exit!");
				break;
			}
			else{
				System.out.println("No such option!");
			}
		}
	}
	
	public static void query(int kNum, Point pt)throws IOException{
		int q_x = (int)pt.getCoord(0), q_y = (int)pt.getCoord(1);
		
		/**
		 * Below is for rtree-based 
		 * */
		System.out.println("Starting Rtree-based Knn");
		MyRtreeBasedVisitor rtreeBasedVisitor = (new knnwithcryop()).new MyRtreeBasedVisitor(kNum, pt);
		myrtree.nearestNeighborQuery(kNum, pt, rtreeBasedVisitor);
		rtreeBasedVisitor.printinfo();
		VO vo = new VO(rtreeBasedVisitor.ids.toArray(new Integer[0]), rtreeBasedVisitor.data.toArray(new IShape[0]), kNum, q_x, q_y, false);
		if(vo.ClientVerify(q_x, q_y)){
			//System.out.println("Pass verification");
		}else{
			System.err.println("Fail verification");
		}
		if(!IS_BATCH_QUERY)vo.statistics.printinfo();
		else vo.statistics.printinfotofile(datapw);
		stat1.Construction_time_for_server += vo.statistics.generate_time;
		stat1.VO_size += vo.statistics.VOsize();
		stat1.Verification_time_for_clients += vo.statistics.verify_time;
		stat1.Pallier_points += vo.statistics.num_of_Pailliar;
		stat1.Line_pairs_points += vo.statistics.num_of_Lines;
		VO vo2 = new VO(rtreeBasedVisitor.ids.toArray(new Integer[0]), rtreeBasedVisitor.data.toArray(new IShape[0]), kNum, q_x, q_y, true);
		if(vo2.ClientVerify(q_x, q_y)){
			//System.out.println("Pass verification");
		}else{
			System.err.println("Fail verification");
		}
		if(!IS_BATCH_QUERY)vo2.statistics.printinfo();
		else vo2.statistics.printinfotofile(datapw);
		stat2.Construction_time_for_server += vo2.statistics.generate_time;
		stat2.VO_size += vo2.statistics.VOsize();
		stat2.Verification_time_for_clients += vo2.statistics.verify_time;
		stat2.Pallier_points += vo2.statistics.num_of_Pailliar;
		stat2.Line_pairs_points += vo2.statistics.num_of_Lines;
		/*
		 * Below is knn with Geo function
		 * */ 
		System.out.println("Starting Voronoi-based Knn");
		MyVisitor visitor = (new knnwithcryop()).new MyVisitor();
		rtree.nearestNeighborQuery(kNum, pt, visitor);
		utility.geo.VO voOfLine = new utility.geo.VO((Integer [])visitor.p_id.toArray(new Integer[0]), (Integer[])visitor.p_x.toArray(new Integer[0]), (Integer[])visitor.p_y.toArray(new Integer[0]), q_x, q_y, false);
		if(voOfLine.ClientVerify(q_x, q_y)){
			//System.out.println("Pass verification!");
		}
		else System.out.println("Fail verification!");
		if(!IS_BATCH_QUERY)voOfLine.statistics.printinfo();
		else voOfLine.statistics.printinfotofile(datapw);
		stat3.Construction_time_for_server += voOfLine.statistics.generate_time;
		stat3.VO_size += voOfLine.statistics.VOsize();
		stat3.Verification_time_for_clients += voOfLine.statistics.verify_time;
		stat3.Pallier_points += voOfLine.statistics.num_of_Pailliar;
		stat3.Line_pairs_points += voOfLine.statistics.num_of_Lines;
		
		utility.geo.VO voOfLine2 = new utility.geo.VO((Integer [])visitor.p_id.toArray(new Integer[0]), (Integer[])visitor.p_x.toArray(new Integer[0]), (Integer[])visitor.p_y.toArray(new Integer[0]), q_x, q_y, true);	
		if(voOfLine2.ClientVerify(q_x, q_y)){
			//System.out.println("Pass verification!");
		}
		else System.out.println("Fail verification!");
		if(!IS_BATCH_QUERY)voOfLine2.statistics.printinfo();
		else voOfLine2.statistics.printinfotofile(datapw);
		stat4.Construction_time_for_server += voOfLine2.statistics.generate_time;
		stat4.VO_size += voOfLine2.statistics.VOsize();
		stat4.Verification_time_for_clients += voOfLine2.statistics.verify_time;
		stat4.Pallier_points += voOfLine2.statistics.num_of_Pailliar;
		stat4.Line_pairs_points += voOfLine2.statistics.num_of_Lines;
	}
	class MyVisitor implements IVisitor{
		public ArrayList<Integer> p_id, p_x, p_y;
		
		public MyVisitor() {
			// TODO Auto-generated constructor stub
			p_x = new ArrayList<Integer>();
			p_y = new ArrayList<Integer>();
			p_id = new ArrayList<Integer>();
		}
		
		@Override
		public ArrayList<String> getVOStringArray() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void searchFinished(int arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void setParentCellInside(boolean arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void setParentNodeInside(boolean arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void visitData(IData arg0) {
			// TODO Auto-generated method stub
			Region region = (Region)arg0.getShape();
			//System.out.println(arg0.getIdentifier() + " : " + (int)region.getLow(0) + " " + (int)region.getLow(1));
			p_id.add(arg0.getIdentifier());
			p_x.add((int)region.getLow(0));
			p_y.add((int)region.getLow(1));
		}

		@Override
		public void visitNode(INode arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void visitNode(INode arg0, int arg1) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void visitNode(INode arg0, int arg1, int[] arg2) {
			// TODO Auto-generated method stub
			
		}
		
		public void printinfo(){
			System.out.println("");
		}
	}
	class MyRtreeBasedVisitor implements IVisitor{

		public int kNum;
		public ArrayList<IShape> data;
		public ArrayList<Integer> ids;
		public Point pt;
		
		public MyRtreeBasedVisitor(int kNumm, Point pt) {
			// TODO Auto-generated constructor stub
			this.kNum = kNum;
			this.pt = pt;
			data = new ArrayList<IShape>();
			ids = new ArrayList<Integer>();
		}
		@Override
		public ArrayList<String> getVOStringArray() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void searchFinished(int arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void setParentCellInside(boolean arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void setParentNodeInside(boolean arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void visitData(IData arg0) {
			// TODO Auto-generated method stub
			int loc = Collections.binarySearch(data, arg0.getShape(), new Comparator<IShape>() {

				@Override
				public int compare(IShape o1, IShape o2) {
					// TODO Auto-generated method stub
					double d1 = pt.getMinimumDistance(o1);
					double d2 = pt.getMinimumDistance(o2);
					if(d1 < d2)return -1;
					else if(d1 == d2)return 0;
					else return 1;
				}
			});
			if(loc >= 0){
				data.add(loc, arg0.getShape());
				ids.add(loc, arg0.getIdentifier());
			}else{
				data.add((-loc - 1), arg0.getShape());
				ids.add((-loc - 1), arg0.getIdentifier());
			}
		}

		@Override
		public void visitNode(INode arg0) {
			// TODO Auto-generated method stub
			int loc = Collections.binarySearch(data, arg0.getShape(), new Comparator<IShape>() {

				@Override
				public int compare(IShape o1, IShape o2) {
					// TODO Auto-generated method stub
					double d1 = pt.getMinimumDistance(o1);
					double d2 = pt.getMinimumDistance(o2);
					if(d1 < d2)return -1;
					else if(d1 == d2)return 0;
					else return 1;
				}
			});
			if(loc >= 0){
				data.add(loc, arg0.getShape());
				ids.add(loc, arg0.getIdentifier());
			}else{
				data.add((-loc - 1), arg0.getShape());
				ids.add((-loc - 1), arg0.getIdentifier());
			}
		}

		@Override
		public void visitNode(INode arg0, int arg1) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void visitNode(INode arg0, int arg1, int[] arg2) {
			// TODO Auto-generated method stub
			
		}
		
		public void printinfo(){
			System.out.println("===========================");
			System.out.println("VO size : " + data.size());
			for(int i = 0; i < data.size(); i++){
				Region region = data.get(i).getMBR();
				System.out.println(region.toString());
			}
		}
	}
	class Stat{
		long Construction_time_for_server;
		int VO_size;
		long Verification_time_for_clients;
		int Pallier_points;
		int Line_pairs_points;
		public void reset(){
			Construction_time_for_server = 0;
			VO_size = 0;
			Verification_time_for_clients = 0;
			Pallier_points = 0;
			Line_pairs_points = 0;
		}
		public Stat(){
			reset();
		}
		public void print(double num){
			System.out.println("===============================================");
			System.out.println("Construction_time_for_server : " + Construction_time_for_server / num);
			System.out.println("VO_size : " + VO_size / num);
			System.out.println("Verification_time_for_clients : " + Verification_time_for_clients / num);
			System.out.println("Pallier_points : " + Pallier_points / num);
			System.out.println("Line_pairs_points : " + Line_pairs_points / num);
		}
		
		public void printtoffile(double num, PrintWriter pw){
			pw.println(Construction_time_for_server / num);
			pw.println(VO_size / num);
			pw.println(Verification_time_for_clients / num);
			pw.println(Pallier_points / num);
			pw.println(Line_pairs_points / num);
			pw.println("");
		}
	}
}
