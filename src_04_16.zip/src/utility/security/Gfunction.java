package utility.security;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;

import utility.Hasher;
import utility.SecurityUtility;

public class Gfunction {
	
	public long L, U;
	public String r = "something";
	public String[][] GvalueU, GvalueL;
	String[] SignedByDO, ServerReturned;
	public int[][] valueU, valueL;
	public long v;
	public static int base = 2, m;
	
	public Gfunction(long x, int _base, long _L, long _U) {
		// TODO Auto-generated constructor stub
		L = _L;
		U = _U;
		v = x;
		base = _base;
		m = (int)(Math.log(U - L) / Math.log(base));
		GenerateU();
		GenerateL();
	}
	
	public Gfunction() {
		// TODO Auto-generated constructor stub
	}

	public static String HashXmore1times(String s, long m){
		if(m < 0)return null;
		String ans = s;
		while(m -- >= 0){
			ans = Hasher.hashString(ans);
		}
		return ans;
	}
	
	public static String HashXtimes(String s, long m){
		if(m < 0)return null;
		String ans = s;
		while(m -- > 0){
			ans = Hasher.hashString(ans);
		}
		return ans;
	}
	
	public void GenerateU(){
		GvalueU = new String[m + 1][m + 1];
		valueU = new int[m + 1][m + 1];
		for(int i = 0; i < m + 1; i++){
			long t = U - v;
			//long t = U - x - 1; //if '=' is not allowed
			for(int j = 0; j < m + 1; j++){
				if(j == 0){
					valueU[i][j] = (int) (t % base + base);
					GvalueU[i][j] = HashXmore1times(r, valueU[i][j]);
				}else if(j <= i){
					valueU[i][j] = (int) (t % base + base - 1);
					GvalueU[i][j] = HashXmore1times(r, valueU[i][j]);
				}else if( j == i + 1){
					valueU[i][j] = (int) (t % base - 1);
					GvalueU[i][j] = HashXmore1times(r, valueU[i][j]);
				}else{
					valueU[i][j] = (int) (t % base);
					GvalueU[i][j] = HashXmore1times(r, valueU[i][j]);
				}
				t /= base;
			}
		}
		long t = U - v;
		for(int i = 0; i < m + 1; i++){
			valueU[m][i] = (int) (t % base);
			t /= base;
			GvalueU[m][i] = HashXmore1times(r, valueU[m][i]);
		}
	}
	
	public void GenerateL(){
		GvalueL = new String[m + 1][m + 1];
		valueL = new int[m + 1][m + 1];
		for(int i = 0; i < m; i++){
			long t = v - L;
			//long t = x - L - 1; // if '=' is not allowed
			for(int j = 0; j < m + 1; j++){
				if(j == 0){
					valueL[i][j] = (int) (t % base + base);
					GvalueL[i][j] = HashXmore1times(r, valueL[i][j]);
				}else if(j <= i){
					valueL[i][j] = (int) (t % base + base - 1);
					GvalueL[i][j] = HashXmore1times(r, valueL[i][j]);
				}else if( j == i + 1){
					valueL[i][j] = (int) (t % base - 1);
					GvalueL[i][j] = HashXmore1times(r, valueL[i][j]);
				}else{
					valueL[i][j] = (int) (t % base);
					GvalueL[i][j] = HashXmore1times(r, valueL[i][j]);
				}
				t /= base;
			}
		}
		long t = v - L;
		for(int i = 0; i < m + 1; i++){
			valueL[m][i] = (int) (t % base);
			t /= base;
			GvalueL[m][i] = HashXmore1times(r, valueL[m][i]);
		}
	}
	
	public void GenerateVeryfyPart(long x){
		//ServerReturned = new String[m + 1];
		SignedByDO = new String[m + 1];
		ServerReturned = new String[m + 1];
		if(v >= x){
			x = x - L;
			int[] can = new int[m + 1];
			boolean ok = true;
			for(int i = 0; i < m + 1; i++){
				can[i] = (int) (x % base);
				x /= base;
				if(can[i] > valueL[m][i])ok = false;
			}
			if(ok){
				for(int i = 0; i < m + 1; i++){
					SignedByDO[i] = GvalueL[m][i];
					ServerReturned[i] = HashXmore1times(r, valueL[m][i] - can[i]);
				}
				return ;
			}
			for(int i = m; i >= 0; i--){
				ok = true;
				for(int j = 0; j < m + 1; j++){
					if(valueL[i][j] < can[j]){
						ok = false;
						break;
					}
				}
				if(ok){
					for(int j = 0; j < m + 1; j++){
						ServerReturned[j] = HashXmore1times(r, valueL[i][j] - can[j]);
						SignedByDO[j] = GvalueL[i][j];
					}
					return;
				}
			}
		}else{
			x = U - x;
			int[] can = new int[m + 1];
			boolean ok = true;
			for(int i = 0; i < m + 1; i++){
				can[i] = (int) (x % base);
				x /= base;
				if(can[i] > valueU[m][i])ok = false;
			}
			if(ok){
				//SignedByDO = GvalueU[m];
				for(int i = 0; i < m + 1; i++){
					SignedByDO[i] = GvalueU[m][i];
					ServerReturned[i] = HashXmore1times(r, valueU[m][i] - can[i]);
				}
				return ;
			}
			for(int i = m; i  >= 0; i--){
				ok = true;
				for(int j = 0; j < m + 1; j ++){
					if(valueU[i][j] < can[j]){
						ok = false;
						break;
					}
				}
				if(ok){
					for(int j = 0; j < m + 1; j++){
						ServerReturned[j] = HashXmore1times(r, valueU[i][j] - can[j]);
						SignedByDO[j] = GvalueU[i][j];
					}
					return;
				}
			}
		}
	}
	
	public boolean ClientVerifyU(long x){
		long can;
		//x = U - x; 
		if(x < 0)return false;
		//long start = System.currentTimeMillis();
		for(int i = 0; i < m + 1; i++){
			can = (x % base);
			x /= base;
			if(HashXtimes(ServerReturned[i], can).equals(SignedByDO[i]) == false)return false;
		}
		//System.out.println("clientverify time : " + (System.currentTimeMillis() - start));
		return true;
	}
	
	public boolean ClientVerifyL(long x){
		long can;
		//x = x - L;
		x = -x;
		if(x < 0)return false;
		for(int i = 0; i < m + 1; i++){
			can = (x % base);
			x /= base;
			if(HashXtimes(ServerReturned[i], can).equals(SignedByDO[i]) == false)return false;
		}
		return true;
	}
	
	public static void main(String[] args){
		long val = 1000, x = 2345, times = 1000;
		Gfunction gf = new Gfunction(val, 10, 0, (long)1 << 30);
		gf.GenerateVeryfyPart(x);
		long start = System.currentTimeMillis(), cputime;
		for(int i = 0 ; i < times; i ++){
			if(gf.ClientVerifyL(gf.L - x) || gf.ClientVerifyU(gf.U - x)){
				//System.out.println("Pass verification!");
			}else {
				System.out.println("Fail verification!");
				break;
			}
		}
		cputime = System.currentTimeMillis() - start;
		System.out.println("Pass G function " + times + "times consume cputime : " + cputime);
	}
	
	public static String[] ClientComputed(String[] ServerReturned, long x) throws Exception{
		long can;
		int m = ServerReturned.length;
		String[] ans = new String[m];
		if(x < 0){
			throw new Exception("value of x < 0!");
		}
		for(int i = 0; i < m; i++){
			can = (x % base);
			x /= base;
			ans[i] = HashXtimes(ServerReturned[i], can);
		}
		return ans;

	}
	
	public void writeToFile(DataOutputStream dos){
		/*
		 * 	public long L, U;
			public String r = "something";
			public String[][] GvalueU, GvalueL;
			public int[][] valueU, valueL;
			public long v;
			public int base, m;
		 * */
		try {
			dos.writeLong(L);
			dos.writeLong(U);
			/*dos.writeInt(GvalueU.length);
			for(int i = 0 ; i < GvalueU.length; i++){
				dos.writeInt(GvalueU[i].length);
				for(int j = 0; j < GvalueU[i].length; j++){
					if(GvalueU[i][j] == null)dos.writeInt(0);
					else{
						byte[] data = GvalueU[i][j].getBytes();
						dos.writeInt(data.length);
						dos.write(data);
					}
				}
			}
			dos.writeInt(GvalueL.length);
			for(int i = 0 ; i < GvalueL.length; i++){
				dos.writeInt(GvalueL[i].length);
				for(int j = 0; j < GvalueL[i].length; j++){
					if(GvalueL[i][j] == null)dos.writeInt(0);
					else{
						byte[] data = GvalueL[i][j].getBytes();
						dos.writeInt(data.length);
						dos.write(data);
					}
				}
			}
			dos.writeInt(valueU.length);
			for(int i = 0; i < valueU.length; i++){
				dos.writeInt(valueU[i].length);
				for(int j = 0; j < valueU[i].length; j++){
					dos.writeInt(valueU[i][j]);
				}
			}
			dos.writeInt(valueL.length);
			for(int i = 0; i < valueL.length; i++){
				dos.writeInt(valueL[i].length);
				for(int j = 0; j < valueL[i].length; j++){
					dos.writeInt(valueL[i][j]);
				}
			}*/
			dos.writeLong(v);
			dos.writeInt(base);
			//dos.writeInt(m);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static int seekLen(DataInputStream dis){
		int ans = 0;
		try {
			ans += 8 * 2 + 8 + 4;
			dis.skipBytes(ans);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ans;
	}
	
	public void readFromFile(DataInputStream dis){
		try {
			L = dis.readLong();
			U = dis.readLong();
			/*int length = dis.readInt();
			GvalueU = new String[length][];
			for(int i = 0 ; i < GvalueU.length; i++){
				length = dis.readInt();
				GvalueU[i] = new String[length];
				for(int j = 0; j < GvalueU[i].length; j++){
					int len = dis.readInt();
					byte[] data = new byte[len];
					dis.read(data, 0, len);
					if(len == 0)GvalueU[i][j] = null;
					else GvalueU[i][j] = new String(data);
				}
			}
			length = dis.readInt();
			GvalueL = new String[length][];
			for(int i = 0 ; i < GvalueL.length; i++){
				length = dis.readInt();
				GvalueL[i] = new String[length];
				for(int j = 0; j < GvalueL[i].length; j++){
					int len = dis.readInt();
					byte[] data = new byte[len];
					dis.read(data, 0, len);
					if(len == 0)GvalueL[i][j] = null;
					else GvalueL[i][j] = new String(data);
				}
			}
			length = dis.readInt();
			valueU = new int[length][];
			for(int i = 0; i < valueU.length; i++){
				length = dis.readInt();
				valueU[i] = new int[length];
				for(int j = 0; j < valueU[i].length; j++){
					valueU[i][j] = dis.readInt();
				}
			}
			length = dis.readInt();
			valueL = new int[length][];
			for(int i = 0; i < valueL.length; i++){
				length = dis.readInt();
				valueL[i] = new int[length];
				for(int j = 0; j < valueL[i].length; j++){
					valueL[i][j] = dis.readInt();
				}
			}*/
			v = dis.readLong();
			base = dis.readInt();
			m = (int)(Math.log(U - L) / Math.log(base)) + 2;
			//m = dis.readInt();
			GenerateU();
			GenerateL();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String HashCode(){
		ArrayList<BigInteger> hashfactors = new ArrayList<BigInteger>();
		hashfactors.add(new BigInteger(new Long(L).toString()));
		hashfactors.add(new BigInteger(new Long(U).toString()));
		hashfactors.add(new BigInteger(new Integer(base).toString()));
		for(String x : SignedByDO){
			hashfactors.add(new BigInteger(x, 16));
		}
		return SecurityUtility.computeHashValue(hashfactors.toArray(new BigInteger[0]));
		
	}
}
