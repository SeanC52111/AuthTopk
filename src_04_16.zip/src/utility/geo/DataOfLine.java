package utility.geo;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class DataOfLine {
	public Long[] ids;
	public Line[] lines;
	public DataOfLine(){
	}
	
	public DataOfLine(Long[] _ids, Line[] _lines){
		ids = new Long[_ids.length];
		lines = new Line[_ids.length];
		ids = _ids;
		lines = _lines;
	}
	
	public DataOfLine(byte[] buf){
		this.loadFromBytes(buf);
	}
	
	public void load(DataInputStream dis){
		int len;
		try {
			len = dis.readInt();
			ids = new Long[len];
			lines = new Line[len];
			for(int i = 0; i < len; i++){
				ids[i] = dis.readLong();
				lines[i] = new Line();
				lines[i].readFromFile(dis);
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static int seekLen(DataInputStream dis){
		int ans = 0;
		try {
			ans += 4;
			int len = dis.readInt();
			for(int i = 0; i < len; i++){
				ans += 8;
				dis.skipBytes(8);
				ans += Line.seekLen(dis);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ans;
	}
	
	public void loadFromBytes(byte[] buf){
		DataInputStream dis = new DataInputStream(new ByteArrayInputStream(buf));
		int len;
		try {
			len = dis.readInt();
			ids = new Long[len];
			lines = new Line[len];
			for(int i = 0; i < len; i++){
				ids[i] = dis.readLong();
				lines[i] = new Line();
				lines[i].readFromFile(dis);
				
			}
			dis.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public byte[] writeToBytes(){
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);
		try {
			dos.writeInt(ids.length);
			for(int i = 0; i < ids.length; i++){
				dos.writeLong(ids[i]);
				lines[i].writeToFile(dos);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return baos.toByteArray();
	} 
}
