package utility.Compare;

import java.math.BigInteger;

import spatialindex.rtree.NSecurityTree;
import utility.SecurityUtility;
import utility.security.IVo;
import utility.security.Paillier;
import utility.security.Point;
import utility.security.RSA;

public class DistanceCompare implements IVo{
	public Point pL, pH;
	public BigInteger[] factors;
	public BigInteger diff, diffbase;
	//public String[] SignedByDO, ServerReturned;
	public static Paillier pailliar = NSecurityTree.pailliar;
	public RSA rsa;
	public BigInteger RSAValueByServer;
	
	public DistanceCompare(Point _pL, Point _pH, boolean isLoad){
		pL = new Point(_pL, isLoad);
		pH = new Point(_pH, isLoad);
	}
	
	public DistanceCompare(Point _pL, Point _pH){
		pL = new Point(_pL);
		pH = new Point(_pH);
		init();
	}
	
	public DistanceCompare(int x1, int y1, int x2, int y2){
		pL = new Point(x1, y1);
		pH = new Point(x2, y2);
		init();
	}
	
	public DistanceCompare(int[] _pL, int[] _pH ){
		pL = new Point(_pL);
		pH = new Point(_pH);
		init();
	}
	
	public void init(){
		pL.buildByPaillier();
		pH.buildByPaillier();
	}
	
	public void GenerateVeryfyPart(Point Q){
		factors = Point.buildFactorsByPaillier(pL, pH, Q.x, Q.y);
		
		//Actually, here all the seeds should be calculated in the mode of Condensed-RSA, I will change the code later.
		BigInteger zero = NSecurityTree.ZeroOfPailliar;
		diff = zero;
		diffbase = zero;
		//System.err.println(pailliar.Decryption(zero));
		for(BigInteger x : factors){
			diff = diff.multiply(x).mod(pailliar.nsquare);
			diffbase = diffbase.multiply(zero).mod(pailliar.nsquare);
		}
		//rsa = new RSA(1024);
		//RSAValueByServer = rsa.encrypt(diff);
	}
	
	public boolean ClientVerify(int q_x, int q_y){
		//long start = System.currentTimeMillis();
//		BigInteger zero = NSecurityTree.ZeroOfPailliar;
//		BigInteger diff = zero, diffbase = zero;
		//System.err.println(pailliar.Decryption(zero));
//		for(BigInteger x : factors){
//			diff = diff.multiply(x).mod(pailliar.nsquare);
//			diffbase = diffbase.multiply(zero).mod(pailliar.nsquare);
//		}
		//System.err.println("factors' length : " + factors.length);
		//System.err.println("time consume : " + (System.currentTimeMillis() - start));
//		start = System.currentTimeMillis();
		BigInteger t1 = pL.CompositionPart1(q_x, q_y).multiply(pH.CompositionPart2(q_x, q_y)).mod(pailliar.nsquare);
		BigInteger t2 = pH.CompositionPart1(q_x, q_y).multiply(pL.CompositionPart2(q_x, q_y)).mod(pailliar.nsquare);
//		System.err.println("time consume : " + (System.currentTimeMillis() - start));
		//System.err.println("t1\'s part1 : " + pailliar.Decryption(pL.CompositionPart1(q_x, q_y)).divide(Point.a2));
		//System.err.println("t1\'s part2 : " + pailliar.Decryption(pL.CompositionPart2(q_x, q_y)).divide(Point.a2));
		//System.err.println("t2\'s part1 : " + pailliar.Decryption(pH.CompositionPart1(q_x, q_y)).divide(Point.a2));
		//System.err.println("t2\'s part2 : " + pailliar.Decryption(pH.CompositionPart2(q_x, q_y)).divide(Point.a2));
//		System.err.println(pailliar.Decryption(diff).divide(Point.a2));
//		System.err.println(pailliar.Decryption(diffbase).divide(Point.a2));
//		System.err.println(pailliar.Decryption(t1).divide(Point.a2));
//		System.err.println(pailliar.Decryption(t2).divide(Point.a2));
		//rsa.decrypt(RSAValueByServer);
		//System.err.println(tmp + " " + diff);
		t1 = t1.multiply(diff).mod(pailliar.nsquare);
		t2 = t2.multiply(diffbase).mod(pailliar.nsquare);
//		System.err.println(pailliar.Decryption(t1));
//		System.err.println(pailliar.Decryption(t2));
		//System.out.println("time consume : " + (System.currentTimeMillis() - start));
		return t1.equals(t2);
	}

	/* (non-Javadoc)
	 * @see utility.security.IVo#getHashcode()
	 */
	@Override
	public String getHashcode() {
		// TODO Auto-generated method stub
		return SecurityUtility.computeHashValue(new BigInteger[]{new BigInteger(pL.HashCode(), 16), new BigInteger(pH.HashCode(), 16)});
	}
}
