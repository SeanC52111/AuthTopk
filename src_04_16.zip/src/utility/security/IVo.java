package utility.security;

public interface IVo {
	public String getHashcode();
	public boolean ClientVerify(int q_x, int q_y);
}
